package com.gangapriya.assignment;

public class employeeutilities {
    public static void displayEmployeeDetails(employee employee) {
        System.out.println("\nEmployee Details:");
        employee.displayInfo();
        System.out.println("-----------------------------");
    }

    public static void increaseSalary(employee employee, double percentage) {
        double newSalary = employee.getSalary() + (employee.getSalary() * (percentage / 100));
        employee.setSalary(newSalary);
        System.out.println("Salary increased by " + percentage + "% for " + employee.getName());
    }
}
