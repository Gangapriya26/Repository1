package com.gangapriya.assignment;

public class Main {
    public static void main(String[] args) {
        // Creating Manager and Developer objects
        Manager manager = new Manager("Alice", 101, 75000, "HR");
        Developer developer = new Developer("Bob", 102, 60000, "Java");

        // Display initial details
        System.out.println("Initial Employee Details:");
        employeeutilities.displayEmployeeDetails(manager);
        employeeutilities.displayEmployeeDetails(developer);

        // Increase salaries
        System.out.println("\nIncreasing Salaries:");
        employeeutilities.increaseSalary(manager, 10);
        employeeutilities.increaseSalary(developer, 15);

        // Display updated details
        System.out.println("\nUpdated Employee Details:");
        employeeutilities.displayEmployeeDetails(manager);
        employeeutilities.displayEmployeeDetails(developer);
    }
}
