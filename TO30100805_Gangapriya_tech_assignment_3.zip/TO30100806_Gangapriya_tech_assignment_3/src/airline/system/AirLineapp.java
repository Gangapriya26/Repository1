package airline.system;

import java.util.Scanner;

public class AirLineapp {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        while (true) {
            System.out.println("Select Airline:\n1. AirIndia\n2. KingFisher\n3. Indigo\n4. Exit");
            int choice = sc.nextInt();
            
            if (choice == 4) {
                System.out.println("Exiting application...");
                break;
          }
            
            System.out.println("Enter hours of travel:");
            int hours = sc.nextInt();
            
            System.out.println("Enter cost per hour:");
            double costPerHour = sc.nextDouble();
            
            AirFare airfare;
            
            switch (choice) {
                case 1:
                    airfare = new AirIndia(hours, costPerHour);
                    break;
                case 2:
                    airfare = new KingFisher(hours, costPerHour);
                    break;
                case 3:
                    airfare = new Indigo(hours, costPerHour);
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
                    continue;
            }
            
            System.out.printf("Total Amount: %.2f\n", airfare.calculateAmount());
        }
        
        sc.close();
    }


}
