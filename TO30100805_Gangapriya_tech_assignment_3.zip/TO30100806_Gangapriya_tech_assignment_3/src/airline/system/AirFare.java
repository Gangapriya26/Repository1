package airline.system;

public interface AirFare {
	double calculateAmount();

}
