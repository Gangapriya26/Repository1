package com.Gangapriya_Assignment2;

import java.util.Scanner;
public class Student {
public Student() {
    System.out.println("Student object is created");
}
}
class Commission {

private String name;
private String address;
private String phone;
private double salesAmount;

public void acceptDetails() {
    Scanner scanner = new Scanner(System.in);
    
    System.out.println("Enter Name:");
    name = scanner.nextLine();
    
    System.out.println("Enter Address:");
    address = scanner.nextLine();
    
    System.out.println("Enter Phone:");
    phone = scanner.nextLine();
    
    System.out.println("Enter Sales Amount:");
    salesAmount = scanner.nextDouble();
}
public void calculateCommission() {
    double commission = 0;
    
    if (salesAmount >= 100000) {
        commission = 0.10 * salesAmount;
    } else if (salesAmount >= 50000) {
        commission = 0.05 * salesAmount;
    } else if (salesAmount >= 30000) {
        commission = 0.03 * salesAmount;
    }
    
    System.out.println("Commission: " + commission);
}
}

