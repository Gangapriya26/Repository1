package com.Gangapriya_Assignment2;

import com.Gangapriya_Assignment2;
import com.Gangapriya_Assignment2;

	public class StudentDetails {
	    public static void main(String[] args) {
	        Student student = new Student();
	        Commission commissionEmployee = new Commission();
	        commissionEmployee.acceptDetails();
	        commissionEmployee.calculateCommission();
	    }
}
	
