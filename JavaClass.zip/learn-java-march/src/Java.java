
public class Java {

}
