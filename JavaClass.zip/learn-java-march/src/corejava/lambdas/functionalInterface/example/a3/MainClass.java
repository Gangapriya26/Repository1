package corejava.lambdas.functionalInterface.example.a3;


public class MainClass {

	public static void main(String[] args) {
		//normal code 
				Animal  cat =new Animal() {
					@Override 
					public void sound(String prefix,String suffix) {
						System.out.println(prefix+"meow meow"+suffix);
						
					}
				};
				cat.sound("@","!");
				
				//code using lambdas
				Animal dog = (s,p) ->{
						System.out.println(p+"Bow Bow"+s);
					};
				dog.sound("^","!!");
				
				//code using  lambdas further improve 
				Animal cow = (Prefix,Suffix)->System.out.println(Prefix+"Ambaaa"+Suffix);
				cow.sound("#","!!!!!");
				
				//code using lambdas further further 
				Animal horse=(p,s)->System.out.println(p+"neigh "+s);
				horse.sound("$","%%%%%%");
	}

}
