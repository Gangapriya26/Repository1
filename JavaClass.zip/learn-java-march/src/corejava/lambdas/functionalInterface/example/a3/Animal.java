package corejava.lambdas.functionalInterface.example.a3;

//functional interface 
//interface having only one abstract method 

public interface Animal {
	public void sound(String prifix,String suffix);
	

}
