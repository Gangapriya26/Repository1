package corejava.lambdas.functionalInterface.example.a4;

public class MainClass {

	public static void main(String[] args) {
		//normal code
		MathOperation addition = new MathOperation() {

			@Override
			public int operation(int a, int b) {
				return a+b;
			}
			
		};
		int result1 =addition.operation(2, 4);
		System.out.println("Addition1= "+result1);
		
		//code using lambdas 
		MathOperation a2=(a,b)->{
			return a+b;
		};
		 int result2=a2.operation(3, 4);
		 System.out.println("Additon2= "+result2);
		 
		 
		 //code using further improve 
		 MathOperation a3=(c,d)->c+d;
		 int result3=a3.operation(5, 7);
		 System.out.println("AdditionS3= "+result3);
		
		
	}

}
