package corejava.lambdas.functionalInterface.example.a4;

public interface MathOperation {
	public int operation (int a ,int b);

}
