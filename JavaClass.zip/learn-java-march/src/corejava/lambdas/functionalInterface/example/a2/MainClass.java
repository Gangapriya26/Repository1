package corejava.lambdas.functionalInterface.example.a2;


public class MainClass {

	public static void main(String[] args) {
		//normal code 
				Animal  cat =new Animal() {
					@Override 
					public void sound(String suffix) {
						System.out.println("meow meow"+suffix);
						
					}
				};
				cat.sound("!");
				
				//code using lambdas
				Animal dog = (s) ->{
						System.out.println("Bow Bow"+s);
					};
				dog.sound("!!");
				
				//code using  lambdas further improve 
				Animal cow = (Suffix)->System.out.println("Ambaaa"+Suffix);
				cow.sound("!!!!!");
				
				//code using lambdas further further 
				Animal horse=s->System.out.println("neigh "+s);
				horse.sound("%%%%%%");
	}

}
