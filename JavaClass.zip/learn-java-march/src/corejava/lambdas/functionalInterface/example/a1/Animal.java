package corejava.lambdas.functionalInterface.example.a1;

public interface Animal {
	public void sound();

}
