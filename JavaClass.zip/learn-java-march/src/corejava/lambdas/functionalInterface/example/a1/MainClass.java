package corejava.lambdas.functionalInterface.example.a1;

public class MainClass {

	public static void main(String[] args) {
		//normal code 
		Animal  cat =new Animal() {
			@Override 
			public void sound() {
				System.out.println("meow meow");
				
			}
		};
		cat.sound();
		
		//code using lambdas
		Animal dog = () ->{
				System.out.println("Bow Bow");
			};
		dog.sound();
		
		//code using  lambdas further improve 
		Animal cow = ()->System.out.println("Ambaaa");
		cow.sound();
	}

}
