package corejava.basics.ch_01_introduction;

//println method
public class PrintLineMethod {

	public static void main(String[] args) {
		// println() //print + line
		// this will create a new line after printing
		System.out.println("hello world");
		System.out.println();
		System.out.println("Hello world");
		System.out.print("hii");
		//escape character backslash
		//backslash is called as a escape character in java
		System.out.println("\" ");
		System.out.println("\\\\" );
		System.out.println("\\"+"\\");
		
		System.out.println("'");
		//we are creating new line string using \n
		System.out.println("We are learning \n Java");
		System.out.println("We are learning \nJava");
		
		
	}
		
}
