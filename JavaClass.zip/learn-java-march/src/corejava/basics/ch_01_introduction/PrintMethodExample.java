package corejava.basics.ch_01_introduction;
// The print method()
//the only differece is that it does not insert new line at the end of output
public class PrintMethodExample {

	public static void main(String[] args) {
		//print method=> only print
		// it will not create a new line after printing
		System.out.print("Hiii  ");
		System.out.print("Kavyaaaa");
		System.out.print("  ");
		System.out.println("you are my sunshine");
		System.out.println("java");

	}

}
