package corejava.basics.ch_01_introduction;
// when working with text
//it must be wrapped inside double quotation marks
// if we forget the double quotes,an error occured

public class PrintText {

	public static void main(String[] args) {
		System.out.println("this sentance will work");
//		System.out.println("this sentance will produce error");

	}

}
