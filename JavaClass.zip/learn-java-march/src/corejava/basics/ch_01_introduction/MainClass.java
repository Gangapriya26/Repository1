package corejava.basics.ch_01_introduction;

public class MainClass {

	public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println();
        System.out.println(26);
	}

}
