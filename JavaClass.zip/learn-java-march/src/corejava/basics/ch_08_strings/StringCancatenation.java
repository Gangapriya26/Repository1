package corejava.basics.ch_08_strings;

public class StringCancatenation {

	public static void main(String[] args) {
		// we can use + for cancatenation
		// joining Srting + String => String

		System.out.println("sun" + "shine");
		System.out.println("sun" + " " + "shine");

		String a = "Sun";
		String b = "Shine";
		System.out.println(a + " " + b);

		// joining Srting + int => String
		String c = "HTML";
		int d = 5;
		System.out.println(c + d);

		// 14=>"14"
		System.out.println(14 + "");
		String x;
		x = 14 + "";
		// how to confirm it is a string
		System.out.println(x + 5);// o/p==145

		// 2. we can concat () method for concatetion

		String subject = "java";
		String text = "Programming";
		System.out.println(subject.concat(text));//javaprogramming
		System.out.println(subject.concat(" " + text));//java Programming
		System.out.println("java".concat("Programming"));//javaProgramming

		String course=":";
		System.out.println(subject+" "+course+" "+text);
		
		String Course ="";
		Course = subject+":"+text;
		System.out.println(Course);
		//
	}

}
