package corejava.basics.ch_08_strings;

public class StringToNumber {

	public static void main(String[] args) {
		String stringNumber="14";
		int number = Integer.parseInt(stringNumber);
		System.out.println(number);
		System.out.println(number+12);

	}

}
