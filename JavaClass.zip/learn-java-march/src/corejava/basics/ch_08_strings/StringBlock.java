package corejava.basics.ch_08_strings;

//String block feature 
//triple double quote
public class StringBlock {

	public static void main(String[] args) {
		String text = " firt line\n second line\nthirt line";
		System.out.println(text);

		String Block;
		Block = """
				Johny Johny,
				Yes, Papa?
				Eating sugar?
				No, papa!
				Telling lies?
				No, papa!
				Open your mouth Ha, ha, ha! """;
		System.out.println(Block);

	}

}
