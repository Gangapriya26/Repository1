package corejava.basics.ch_08_strings;

public class StringMethod {

	public static void main(String[] args) {

		String text = "java";

		// toUppercase()
		// it converts a string to uppercase letters and
		// returns string to upppercase
		String abcd;
		abcd = text.toUpperCase();
		System.out.println(abcd);

		text = "python".toUpperCase();
		System.out.println(text);

		// toLowercase()
		// it converts a string to lowercase letters and
		// returns string to lowerrcase

		System.out.println("PYTHON".toLowerCase());
		text = "JAVA".toLowerCase();
		System.out.println(text);

		boolean isTrueOrFalse;
		// contains ('value")
		// check whether a string contains a sequence of characters
		// returns true if the string contains "value" otherwise false
		isTrueOrFalse = "java".contains("a");
		System.out.println(isTrueOrFalse);

		isTrueOrFalse = "java".contains("J");
		System.out.println(isTrueOrFalse);// false becoz capital J

		// equals ("string")
		// compare two string
		// returns true if the string are equal, otherwise false

		isTrueOrFalse = "apple".equals("apple");
		System.out.println(isTrueOrFalse);

		isTrueOrFalse = "apple".equals("Apple");
		System.out.println(isTrueOrFalse);

		// eqalsIgnoreCase()
		// compare to ignoring case considerations
		// returns true if the string are equal, and false if not

		isTrueOrFalse = "SQL".equalsIgnoreCase("sql");
		System.out.println(isTrueOrFalse);

		// replaceAll("oldText","newText")
		// replace each substring of this string that matches the given
		// regular expression with the given replacement

		text = "hello world".replaceAll("world", "people");

		System.out.println(text);

		// indexOf('character')
		// returns the index or position of character
		// the specifies character in string
		// returns -1 if charactyer is not found

		int index;
		index = "Hello world".indexOf('w');// 0
		System.out.println(index);
		index = "Hello world".indexOf('W');// -1
		System.out.println(index);

		// charAt(index)
		// returns the character value at the specified index or position
		char character;
		character = "java".charAt(2);
		System.out.println(character);

		// length()
		// returns length of specified string
		// returns total length of character in specified string
		int size;
		size = "java".length();
		System.out.println(size);

		// isEmpty()
		// checks whether string is empty or not
		// returns true if the length is zero otherwise false

		isTrueOrFalse = " ".isEmpty();
		System.out.println(isTrueOrFalse);// false

		isTrueOrFalse = "".isEmpty();
		System.out.println(isTrueOrFalse);// true

		// isBlank()
		// returns true if the string is blank
		// or contains only white space otherwise false
		isTrueOrFalse = " ".isBlank();
		System.out.println(isTrueOrFalse);

		// lastIndexOf('character')
		// returns the position or index of last found occurance /
		// of specified character in a string
		// returns -1 if character is not found

		index = "java".lastIndexOf('a');
		System.out.println(index);

		// endsWith ("text")
//tests if this string ends with specified suffix
		// checks whether a string end s with specified character (s)
		// returns true of false
		isTrueOrFalse = "sun shine".endsWith("shine");
		System.out.println(isTrueOrFalse);

		// strtsWith ("text")
		// chechs whether string starts with specified prifix character ()
		// returns true or false

		isTrueOrFalse = "sun shine".startsWith("sun");
		System.out.println(isTrueOrFalse);

		// trim()

		// removes unwanted white spaces from both ends string
		// returns the resulting string
		text = "   sun shine    ".trim();
		System.out.println(text);

	}

}
