package corejava.basics.ch_02_comments;

/**
 * @author ganga
 * @since 17 march 2025 outside main method
 */
public class CommentsExample {

	/*
	 * shortcuts for multi line comments above class name or method name shift + alt
	 * + j inside main method
	 */
	public static void main(String[] args) {
		// single line comments
		// shortcut for single line comment
		// ctrl + forword slash

//		System.out.println("Hello ");
//		System.out.println("world");
		/*
		 * shortcut for multi line comments forword slash / + enter
		 */

	}

}
