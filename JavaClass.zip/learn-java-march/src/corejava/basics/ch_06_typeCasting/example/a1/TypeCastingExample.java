package corejava.basics.ch_06_typeCasting.example.a1;

public class TypeCastingExample {

	public static void main(String[] args) {
		int number = 10;
		System.out.println(number); // 10

		double dnumber = number;
		System.out.println(dnumber); // 10.0

		dnumber = 1.123456789;
		System.out.println(dnumber);// 12345671.12345

		// type casting
		int num = (int) dnumber;
		System.out.println(num);// 1234567

		char name = (char) dnumber;
		System.out.println(name);// nonsence output

		float fnum = (float) dnumber;
		System.out.println(fnum);// 12345671.1

		long lnumber = (long) dnumber;
		System.out.println(lnumber);// 12345671);

		short snum = (short) name;
		System.out.println(snum);

		byte bnum = (byte) dnumber;
		System.out.println(bnum);

	}

}
