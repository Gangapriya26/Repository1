package corejava.basics.ch_04_identifiers.examples.a1;

public class IdentifierExample {

	public static void main(String[] args) {
		// allowed
		String subject = "java";
		String __sub = "sql";
		String $sub = "html";
		int first100number100 = 100;

		// Not allowed
//		int 1sub = 4;  ///cannot start with number
//		int first number = 1; // cannot have space have bw identifier
//		int #number = 2; // cannot start with spl character except $ and _
//		int number# = 5; // cannot end with spl character except $ and _

		// best practice
		int student_roll_number = 032;

		// best practice
		int studentRollNumber = 032;

	}

}
