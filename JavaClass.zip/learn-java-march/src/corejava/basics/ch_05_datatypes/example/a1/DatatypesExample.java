package corejava.basics.ch_05_datatypes.example.a1;

public class DatatypesExample {

	public static void main(String[] args) {
		// string set of character
		String name;
		name = "Hello world";
		System.out.println(name);

		char txt;
		txt = 'A';
		System.out.println(txt);
		
		char character;
		character = 'A';
		System.out.println(character);

		byte nmbr = 123;
		System.out.println(nmbr);

		short no = 12345;
		System.out.println(no);

		int num = 12345678;
		System.out.println(num);

		long number = 123456789;
		System.out.println(number);

		float profit = 10.123F;
		System.out.println(profit);

		double loss = 1234567.1234567;
		System.out.println(loss);

		boolean iseligible = false;
		System.out.println(iseligible);

	}

}
