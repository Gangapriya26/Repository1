package corejava.basics.ch_03_variables.examples;

public class VariableExample_03 {

	public static void main(String[] args) {
		int age = 22;
		System.out.println(age);

		int agE = 21;
		System.out.println(agE);

		int aGe = 21;
		System.out.println(aGe);

		String sub = "java";
		System.out.println(sub);

		sub = "python";
		System.out.println(sub);

		char character = 'A';
		System.out.println(character);

	}

}
