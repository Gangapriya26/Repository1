package corejava.basics.ch_03_variables.examples;

public class VariableExample_01 {

	public static void main(String[] args) {
		int a =76;
		int b= 88;
		System.out.println(a + b);

		// subtraction
		System.out.println(a - b);

		// multiplication
		System.out.println(a * b);

		// division
		System.out.println(b / a);

	}

}
