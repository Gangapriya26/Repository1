package corejava.basics.ch_03_variables.examples;

public class VariableExample_05 {

	public static void main(String[] args) {
		String subject;// Declaration
//		System.out.println(subject);// will throw error
		// String variable have null variable

		subject = "java"; // initialization
		System.out.println(subject);

		int number; // declaration

//		System.out.println(number); // throw error
		// ingt will have zero value if not initialize

		number = 1234; // initialization
		System.out.println(number);

	}

}
