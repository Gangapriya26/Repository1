package corejava.basics.ch_03_variables.examples;

public class VariableExample_04 {

	public static void main(String[] args) {

		int a, b, c;
		a = 1;
		b = 2;
		c = 3;
		int d = 1, e = 2, f = 3;
		int g = a;
		int h, i = 10;
//		System.out.println(h); this line give error

		h = 11;

		System.out.println(a + b + c + d + e + f + g + h + i);
		String subject;
		subject = "java";
		System.out.println(subject);
		subject = new String("python");
		System.out.println(subject);//python

	}

}
