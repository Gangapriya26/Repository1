package corejava.basics.ch_03_variables.examples;

public class VariableExample_02 {

	public static void main(String[] args) {
		String name = "Priya";
		String city = "Chikkamagaluru";
		int age = 22;

		System.out.println(name);
		System.out.println(city);
		System.out.println(age);
	}

}
