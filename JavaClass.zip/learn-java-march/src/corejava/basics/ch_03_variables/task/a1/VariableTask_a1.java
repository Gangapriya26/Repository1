package corejava.basics.ch_03_variables.task.a1;

public class VariableTask_a1 {

//convert the below code using variable
	// 1. name 2.city 3.subject 4.game
	public static void main(String[] args) {
		String name ="Mayank";
		String city = "Baengaluru";
		String subject = "SQL";
		String game = "Football";
		System.out.println("Student name is " + name);
		System.out.println(name + " city is " + city);
		System.out.println(name + " subject is " + subject);
		System.out.println(name + " game is " + game);
	}

}
