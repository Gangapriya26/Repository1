package corejava.basics.ch_09_arrays.example.a1;

import java.util.Arrays;

public class ArrayOfString {

	public static void main(String[] args) {
		String[] subjectArray = { "java", "c", "c++", "python", "a1" };
		String stateArray[] = { "Karnataka", "tamilNadum", "Kerala", "andraPradesh" };
		String[] nameArray = new String[10];
		String cityArray[] = new String[2];
		String petArray[] = new String[] { "Dog", "Cat", "Rat", "Cow" };

		System.out.println(subjectArray);// hash code
		System.out.println(Arrays.toString(subjectArray));

		// you can access an array element by index number
		System.out.println(subjectArray[3]);// python

		// we can to change the value of a specified element
		// refer to the index value

		subjectArray[3] = "SQL";
		System.out.println(subjectArray[3]);// sql

		// to find out how many elements an array as we use lenghth property
		int size = subjectArray.length;
		System.out.println(size);

		// index of last element is array .length minus one
		System.out.println("index of last elment :" + (subjectArray.length - 1));
	}

}
