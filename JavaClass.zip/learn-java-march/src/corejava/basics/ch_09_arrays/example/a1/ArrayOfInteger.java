package corejava.basics.ch_09_arrays.example.a1;

public class ArrayOfInteger {

	public static void main(String[] args) {
		int[] numberArray = { 1, 2, 3, 4, 5 };
		int rollNumber[] = { 032, 043 };
		int[] mobileNumber = new int[3];
		int pincodeArray[] = new int[6];
		int[] registerNumberArray = new int[] { 101, 102, 103 };

		// getting the element value

		System.out.println(numberArray[4]); // 5

		// change the value
		numberArray[4] = 10;
		System.out.println(numberArray[4]);

		// ArrayIndexOutOfboundException
		// the index is either negative
		// or greater than or equal to the size of the array

		System.out.println(numberArray[5]);// exception as arrayOutOfBoundException
		System.out.println(numberArray[-1]);// exception as arrayOutOfBoundException
		

	}

}
