package corejava.basics.ch_11_loops.while_loop.example.a1;

public class WhileLoopExample {

	public static void main(String[] args) {
		//print number from 1 - 5
		
		int number =1;
		while(number<6)
		{
			System.out.println(number);
			number++;
		}

	}

}
