package corejava.basics.ch_11_loops.for_loop.example.a1;

public class ForLoopIncrementExample {

	public static void main(String[] args) {
		//print number from 1- 5
		
		for(int number=1;number<6;number++)
		{
			System.out.println(number);
		}

	}

}
