package corejava.basics.ch_11_loops.for_loop.example.a1;

public class ForLoopDecrementExample {

	public static void main(String[] args) {
		for(int number=6;number>0;number--)
		{
			System.out.println(number);
		}
	}

}
