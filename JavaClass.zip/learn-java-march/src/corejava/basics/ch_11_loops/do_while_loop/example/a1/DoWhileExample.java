package corejava.basics.ch_11_loops.do_while_loop.example.a1;

//do_ while execute at least once irrespective of the  check

public class DoWhileExample {

	public static void main(String[] args) {
		// print number from 1- 5

		int number = 1;
		do {
			System.out.println(number);
			number++;
		} while (number < 6);

	}

}
