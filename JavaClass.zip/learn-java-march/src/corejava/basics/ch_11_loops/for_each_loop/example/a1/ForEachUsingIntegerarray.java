package corejava.basics.ch_11_loops.for_each_loop.example.a1;

public class ForEachUsingIntegerarray {

	public static void main(String[] args) {
		
	}

}
