package corejava.basics.ch_07_operator.logical.example.a1;

//logical operator is use to compare two or more than  different conditions
//logical AND operator - &&
//logical OR operator - ||(pipe symbol)
//logical NOT operator -!
public class LogicalOperatorExample {

	public static void main(String[] args) {
		// LOGICAL and operator - &&
		// returns true or false

		System.out.println(1 == 1 && 2 == 2);
		System.out.println(true && true);// true
		System.out.println(true && false);// false
		System.out.println(false && true);// false
		System.out.println(false && false);// false

		// LOGICAL OR operator - ||
		// returns true or false

		System.out.println(1 == 1 || 2 == 2);
		System.out.println(true || true);// true
		System.out.println(true || false);// true
		System.out.println(false || true);// true
		System.out.println(false || false);// false

		// LOGICAL NOT operator - ||
		// returns true or false

		System.out.println(!true);// FALSE
		System.out.println(!false);// true
		System.out.println(!(!true)); //true

	}

}
