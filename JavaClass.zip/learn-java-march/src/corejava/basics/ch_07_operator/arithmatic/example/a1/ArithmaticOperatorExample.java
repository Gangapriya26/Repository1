package corejava.basics.ch_07_operator.arithmatic.example.a1;

public class ArithmaticOperatorExample {

	public static void main(String[] args) {
		// plus fpr addition
		int a;// declaration
		a = 1;// initialization
		int b = 4;
		int result;
		result = a + b;
		System.out.println(result);// 5

		// "-" for subtraction
		int c = 2;
		int d = 3;
		int z;
		z = d - c;
		System.out.println(z);// 1

		// "*" for multiplication
		int e = 3;
		int f = 5;
		z = e * f;
		System.out.println(z);// 15

		// "/" for devision
		// will return answer/quotient
		int g = 26;
		int m = 29;
		int l;
		l = g / m;
		System.out.println(l);// 0

		// % for modulus
		// will returns remainder

		int j = 23;
		int k = 70;
		l = k % j;
		System.out.println(l);// 0
		System.out.println(k % j);// 0

	}

}
