package corejava.basics.ch_07_operator.comparision.example.a1;

public class ComparisionOperatorExample {
	// comparision operator

	public static void main(String[] args) {
		// "==" check left value is equal to or not
		// "=="equal to or not
		// returns true or false
		boolean isTrueorFalse;
		isTrueorFalse = 1 == 1;
		System.out.println(isTrueorFalse);
		System.out.println(1 == 1);

		int a = 1;
		int b = 1;
		isTrueorFalse = a == b;
		System.out.println(isTrueorFalse);
		System.out.println(a == b);

		// "<" less than operator
		// returns true or false

		System.out.println(-1 < 1);

		// ">" less than operator
		// returns true or false

		System.out.println(-1 > 1);

		// "!=" not equal to operator
		// returns true or false

		System.out.println(-1 != 1);

		// "<=" less than or equal to
		// returns true or false
		// if any one condition true it returns true
		System.out.println(0 <= 1);
		System.out.println(0 <= -1);

		// ">=" less than or equal to
		// returns true or false
		// if any one condition true it returns true
		System.out.println(0 >= 1);
		System.out.println(0 >= -1);

	}

}
