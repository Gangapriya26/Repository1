package corejava.basics.ch_07_operator.ternary.example.a1;

//ternary operator - ?
//
public class ternaryOperatorExample {

	public static void main(String[] args) {
		String a = true ? "java" : "python";
		System.out.println(a);

		a = false ? "java" : "python";
		System.out.println(a);

		System.out.println(true ? 5 : 4);// 5
		System.out.println(false ? 5 : 4);// 4

		// String
		String subject;
		subject = true ? "sql" : "react";
		System.out.println(subject);// sql

		subject = false ? "sql" : "react";
		System.out.println(subject);// react

		// char
		char name;
		name = true ? 'G' : 'M';
		System.out.println(name);

		name = false ? 'G' : 'M';
		System.out.println(name);

		// byte
		byte num;
		num = true ? 1 : 2;
		System.out.println(num);

		num = false ? 1 : 2;
		System.out.println(num);

		// short
		short number;
		number = true ? 112 : 2;
		System.out.println(number);

		number = false ? 11 : 2;
		System.out.println(number);

		// int
		int No;
		No = true ? 1 : 2;
		System.out.println(No);

		No = false ? 1 : 2;
		System.out.println(No);

		// long
		long nbr;
		nbr = true ? 112345 : 2;
		System.out.println(nbr);

		nbr = false ? 112345 : 2;
		System.out.println(nbr);

//		double
		double dnum;
		dnum = true ? 1.12345 : 2.3;
		System.out.println(dnum);

		dnum = false ? 1.12345 : 2.3;
		System.out.println(dnum);

//		float
		float fnum;
		fnum = true ? 0.1F : 0.5F;
		System.out.println(fnum);

		fnum = false ? 0.1F : 0.5F;
		System.out.println(fnum);

//		boolean
		boolean isEligible;
		isEligible = true ? false : true;
		System.out.println(isEligible);

		isEligible = false ? false : true;
		System.out.println(isEligible);

	}
}
