package corejava.basics.ch_07_operator.assignment.example.a1;

public class AssignmentOperatorExample {

	public static void main(String[] args) {
		// "=" assign value from right to left side
		int a = 1;
		System.out.println(a);

		// "++" increment for increase the number
//		a=a+1;//short hand for this ++
		System.out.println(a);
		a = 3;
		a++;
		System.out.println(a);

		a = 4;
		++a;
		System.out.println(a);

		// "--" for decrement

		a--;
		System.out.println(a);
		// increase the value by 3
//		a = a + 4;
//		System.out.println(a);// 5
		a += 4;
		System.out.println(a);// 5
		// decrease the value by 3
		a -= 3;
		System.out.println(a);

		// multiplication
//		a=a*2;//10
		a *= 2;
		System.out.println(a);

		// for devision
//		a =a/2;//2
		a /= 2;
		System.out.println(a);// 2

		// modulus
//		a=a%2;//2
		a %= 2;
		System.out.println(a);

	}

}
