package corejava.basics.ch_07_operator.assignment.example.a2;

public class PreIncrementExample {

	public static void main(String[] args) {
		//++number - pre increment
		//the value of number is increment first by 1
		//before using it 
		int number = 5;
		// number value 5 is incremented to 6 first 
		//then assigned to result
		int result = ++number;
		System.out.println("result:" + result);// 5
		System.out.println("number: "+ number);// 6
	}

}
