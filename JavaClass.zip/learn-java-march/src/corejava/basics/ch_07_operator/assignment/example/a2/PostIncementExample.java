package corejava.basics.ch_07_operator.assignment.example.a2;

public class PostIncementExample {

	public static void main(String[] args) {
		int number = 5;
		//number value is assign to result first 
		//then incremented to 6 
		int result = number++;
		System.out.println("result:" + result);// 5
		System.out.println("number: "+ number);// 6

		
	}

}
