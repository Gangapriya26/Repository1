package corejava.basics.ch_10_if_and_else.task.a1;

import java.util.Scanner;

public class IfAndElseTask {

	public static void main(String[] args) {
		// write a program which can satisfy the given below conditions
		// PRINT "CHILD" if age is more than or equal to 0 but less than 12
		// PRINT "TEEN" if age is more than or equal to 12 but less than 18
		// PRINT "ADULT" if age is more than 18 or equal to 18 but less than 50
		// PRINT "SENIOR" if age is more than 50 or equal to 50 but less than 127
		// PRINT "ENTER VALUES BETWEEN 0 AND 127" for all other values
//		Scanner scanner = new Scanner(System.in);
//		System.out.print("Enter age: ");
//		int age = scanner.nextInt();
		
		int age = 14;
		if (age >= 0 && age < 12) {
			System.out.println("CHILD");
		} else if (age >= 12 && age <= 18) {
			System.out.println("TEEN");
		} else if (age >= 18 && age <= 50) {
			System.out.println("ADULT");

		} else if (age >= 50 && age <= 127) {
			System.out.println("SENIOR");
		} else {
			System.out.println("ENTER THE VALUES BETWEEN 0 AND 127");
		}

	}

}
