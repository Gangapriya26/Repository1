package corejava.basics.ch_10_if_and_else.task.a1;

import java.util.Scanner;

public class IfAndElseUsingUserInput {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter age: ");
		int age = scanner.nextInt();
		scanner.close();

		if (age >= 0 && age < 12) {
			System.out.println("CHILD");
		} else if (age >= 12 && age <= 18) {
			System.out.println("TEEN");
		} else if (age >= 18 && age <= 50) {
			System.out.println("ADULT");

		} else if (age >= 50 && age <= 127) {
			System.out.println("SENIOR");
		} else {
			System.out.println("ENTER THE VALUES BETWEEN 0 AND 127");
		}

	}

}
