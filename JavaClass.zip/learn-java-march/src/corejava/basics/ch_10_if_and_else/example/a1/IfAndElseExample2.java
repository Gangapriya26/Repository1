package corejava.basics.ch_10_if_and_else.example.a1;

//FOR MULTIPLE CONDITIONS
//ELSE IF 
public class IfAndElseExample2 {

	public static void main(String[] args) {
		if (false) {
			// true==>if block
			System.out.println("IF TRUE");

		} else if (false) {
			// true==>else if block
			System.out.println("IF TRUE");

		} else {
			// everything is false ==>else block
			System.out.println("If FALSE");

		}
		if (true) {
			// true==>if block
			System.out.println("IF TRUE");

		} else if (false) {
			// true==>else if block
			System.out.println("IF TRUE");

		} else {
			// everything is false ==>else block
			System.out.println("If FALSE");

		}
		if (false) {
			// true==>if block
			System.out.println("IF TRUE");

		} else if (true) {
			// true==>else if block
			System.out.println("IF TRUE");

		} else {
			// everything is false ==>else block
			System.out.println("If FALSE");

		}
	}

}
