package corejava.basics.ch_10_if_and_else.example.a1;

//IF AND ELSE 
//CONTROLE STATEMENT
public class IfAndElseExample1 {

	public static void main(String[] args) {
		if (true) {
			// if block or true block
			System.out.println("1:CONDITION IS TRUE");
		} else {
			// else block or false block
			System.out.println("1:CONDITION IS FALSE");
		}
		if (false) {
			// if block or true block
			System.out.println("2:CONDITION IS TRUE");
		} else {
			// else block or false block
			System.out.println("2S:CONDITION IS FALSE");
		}

		// this is not a best practice
		if (true)
			System.out.println("3:CONDITION IS TRUE");
		System.out.println("3:ANYTHING");

		if (false)
			System.out.println("4:CONDITION IS TRUE");
		System.out.println("4:ANYTHING");

	}

}
