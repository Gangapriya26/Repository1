package corejava.basics.ch_12_switch.example.a1;

public class BreakWithForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
