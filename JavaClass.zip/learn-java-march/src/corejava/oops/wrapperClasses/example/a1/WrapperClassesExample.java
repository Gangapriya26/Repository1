package corejava.oops.wrapperClasses.example.a1;

public class WrapperClassesExample {

	public static void main(String[] args) {
//		String text="java";
		String text=new String ("java");
		System.out.println(text);
		
//		int number = new int(10); //we cannot create like this because it is inbuilt 
		
		Integer nmbr = new Integer(10);//this is deprecated ///not recommended
		System.out.println("number 1="+nmbr);
		
		Integer number =10;
		System.out.println("number2="+number );
		
		String x = "10";
		int y = Integer.parseInt(x);//static method 
		System.out.println(y);
		
		Character ch1= new Character ('A');//this is deprecated //not recommended 
		System.out.println(ch1);
		
		Character ch2='B';
		System.out.println(ch2);
		
		Byte byteNUmber1=124;
		System.out.println(byteNUmber1);
		
		Short shortNumber =12345;
		System.out.println(shortNumber);
		
		Long longNumber=1_234_2132L;
		System.out.println(longNumber);
		
		Float floatnumber =1.3f;
		System.out.println(floatnumber);
		
		Double doubleNumber=12.123;
		System.out.println(doubleNumber);
		
		Boolean flag=true;//default value of wrapper class boolean is null
		System.out.println(flag);//                                   ~~~~
		
	}

}
