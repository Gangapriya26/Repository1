package corejava.oops.objectClass.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Goat g1=new Goat();
//		System.out.println(g1);  //hash code //af        
		g1.name="Kattappa";
		g1.age=36;
		System.out.println(g1);
	}

}
