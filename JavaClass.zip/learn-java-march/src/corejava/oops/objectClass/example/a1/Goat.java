package corejava.oops.objectClass.example.a1;

public class Goat {
	public String name;
	public int age;
	
	@Override
	public String toString() {
		return "Goat[name="+name+",age = "+age+"]";
			
	}
}
