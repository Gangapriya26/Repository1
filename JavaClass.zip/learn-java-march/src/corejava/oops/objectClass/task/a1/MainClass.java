package corejava.oops.objectClass.task.a1;

public class MainClass {
	
	// Create a Manager class
		// in Manager class create 3 instance variables namely
		// 1. name of type string
		// 2. city of type string
		// 3. age of type int
		// create a object of Manager class in main method
		// give the values to the object and
		// show the string value of object in console

	public static void main(String[] args) {
		Manager m1=new Manager();
		m1.name="Karan";
		m1.city="Chikkamagaluru";
		m1.age=34;
		System.out.println(m1);
		

	}

}
