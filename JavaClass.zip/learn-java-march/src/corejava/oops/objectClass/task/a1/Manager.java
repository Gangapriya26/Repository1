package corejava.oops.objectClass.task.a1;

public class Manager {
	public String name;
	public String city;
	public int age;
	@Override
	public String toString() {
		return "Manager [name=" + name + ", city=" + city + ", age=" + age + "]";
	}
	

	

}
