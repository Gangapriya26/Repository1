package corejava.oops.superKeyword.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Cat c1=new Cat();
		c1.x();
	}

}
