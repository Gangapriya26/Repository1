package corejava.oops.superKeyword.example.a1;

public class Animal {
	public int age;
	public String name;
	
	
	//default constructor
	public Animal() {
		
	}
	public void makeNoise() {
		System.out.println("Hello im animal");
	}
	public void eat() {
		System.out.println("munch munch");
	}
	
	private void doSomethingPrivate() {
		System.out.println("this is private method");
	}

}
