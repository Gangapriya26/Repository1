package corejava.oops.superKeyword.example.a1;

public class Cat extends Animal {
	public String catFoodPreference;

	@Override
	public void makeNoise() {
		System.out.println("meow meow");
	}

	public void x() {
		super.makeNoise();

		// no need super keyword becoz no eat method
//		super.eat();
		eat();
		// even with super keyword not allowed for private fields and method
//		super.doSomethingPrivate();
	}
}
