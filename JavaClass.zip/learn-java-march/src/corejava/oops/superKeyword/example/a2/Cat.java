package corejava.oops.superKeyword.example.a2;

public class Cat extends Animal {
	public String catFoodPreference;
	
	//constructor with parameter
	public Cat(int age,String name,String catFoodPreference) {
		//super be the first statement
//		System.out.println("hii mom");
		super(age,name);
//		this.age=age;
//		this.name=name;
		this.catFoodPreference=catFoodPreference;
	}
	@Override
	public void makeNoise() {
		System.out.println("meow meow");
	}

	public void x() {
		super.makeNoise();

		// no need super keyword becoz no eat method
//		super.eat();
		eat();
		// even with super keyword not allowed for private fields and method
//		super.doSomethingPrivate();
	}
	// super keyword cannot be used in a static context:
//	public static void attack() {

//		super.makeNoise();
	public void jump() {
		System.out.println("cat"+super.name+"is jumping over the wall");
		
	}
}
