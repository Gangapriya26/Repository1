package corejava.oops.superKeyword.example.a2;

public class Animal {
	public int age;
	public String name;

	// default constructor
	public Animal() {

	}

	// constructor with parameters

	public Animal(int age, String name) {
		this.age = age;
		this.name = name;
	}

	public void makeNoise() {
		System.out.println("Hello im animal");
	}

	public void eat() {
		System.out.println("munch munch");
	}

	private void doSomethingPrivate() {
		System.out.println("this is private method");
	}
//	public static void main(String[] args) {
//		Animal a1=new Animal();
//		a1.doSomethingPrivate();
//	}

}
