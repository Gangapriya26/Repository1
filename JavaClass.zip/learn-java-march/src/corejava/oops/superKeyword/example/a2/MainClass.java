package corejava.oops.superKeyword.example.a2;

public class MainClass {

	public static void main(String[] args) {
		Cat c1=new Cat(2,"CAt","Chicken");
		System.out.println("age"+c1.age);
		System.out.println("name"+c1.name);
		System.out.println("foodPreference"+c1.catFoodPreference);
		c1.x();
		c1.jump();
	}

}
