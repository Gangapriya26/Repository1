package corejava.oops.treads.example.a1;

public class CountDownUsingTread {

	public static void main(String[] args) throws InterruptedException {
		
		for (int i = 30; i > 0; i--) {
			 System.out.println("i="+i);
			 Thread.sleep(1000);
			 
			 
//		for (int i = 30; i > 0; i--) {
//			 System.out.println("i="+i);
//			 try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();}}

		}
	}
}
