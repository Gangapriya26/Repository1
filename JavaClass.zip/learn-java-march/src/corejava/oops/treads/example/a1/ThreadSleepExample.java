package corejava.oops.treads.example.a1;

public class ThreadSleepExample {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Thread is about to sleeep now ");
		System.out.println("Wait 10 sec thread will wake up");
		
		Thread.sleep(10000);
		
		System.out.println("Thread is awake now ");
	}

}
