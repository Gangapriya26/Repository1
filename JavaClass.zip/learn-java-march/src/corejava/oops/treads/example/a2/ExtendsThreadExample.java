package corejava.oops.treads.example.a2;

public class ExtendsThreadExample extends Thread{
	public void run() {
		System.out.println("This code is running in a thread method ");
	}
	
	

}
