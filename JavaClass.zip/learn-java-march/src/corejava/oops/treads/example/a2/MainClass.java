package corejava.oops.treads.example.a2;

public class MainClass {

	public static void main(String[] args) {
	ExtendsThreadExample t1=new ExtendsThreadExample();
	ExtendsThreadExample t2=new ExtendsThreadExample();
	
	t1.run();
	t2.run();
	
	String n1=t1.getName();
	System.out.println("Thread 1 name="+n1);
	
	String n2=t2.getName();
	System.out.println("Thread 2 name="+n2);
	
	throw new RuntimeException();
	}

}
