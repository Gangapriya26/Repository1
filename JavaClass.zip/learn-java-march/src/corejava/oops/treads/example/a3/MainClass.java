package corejava.oops.treads.example.a3;

public class MainClass {
	public static void main(String[] args) {
		ImplementsRunnableExample t1=new ImplementsRunnableExample();
		ImplementsRunnableExample t2=new ImplementsRunnableExample();
		
		t1.run();
		t2.run();

	}
}
