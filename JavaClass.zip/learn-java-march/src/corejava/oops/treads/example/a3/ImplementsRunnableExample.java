package corejava.oops.treads.example.a3;

public class ImplementsRunnableExample implements Runnable {

	@Override
	public void run() {
		System.out.println("this is running in a thread ");
	}
	


	
}
