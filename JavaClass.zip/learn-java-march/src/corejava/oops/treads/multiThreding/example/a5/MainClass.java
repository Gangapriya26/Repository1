package corejava.oops.treads.multiThreding.example.a5;

public class MainClass {

	public static void main(String[] args) {
		for (int i = 1; i < 6; i++) {
			MultiThreading t1 = new MultiThreading(i);
			Thread thread = new Thread(t1);
			thread.start();
		}
		
		
//		throw new RuntimeException();

	}

}
