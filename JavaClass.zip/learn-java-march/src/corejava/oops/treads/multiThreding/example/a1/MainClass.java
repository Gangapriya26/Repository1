package corejava.oops.treads.multiThreding.example.a1;

public class MainClass {

	public static void main(String[] args) {
		MultiThreading t1=new MultiThreading();
		MultiThreading t2=new MultiThreading();
		
		
//		t1.run();
//		t2.run();
		
		t1.start();
		t2.start();
	}

}
