package corejava.oops.treads.multiThreding.example.a6;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		for (int i = 1; i < 6; i++) {
			MultiThreading t1 = new MultiThreading(i);
			Thread thread = new Thread(t1);
			thread.start();

			boolean flag;
			// isAlive()
			// Tests if this thread is alive.
			// A thread is alive if it has been started and has not yet died.
			// Returns true if this thread is alive, otherwise false

			flag = thread.isAlive();

			// getNmae()
			// returns this threadName

			if (flag == true) {
				System.out.println(thread.getName() + ": is alive ");

			} else {
				System.out.println(thread.getName() + ": is dead ");

			}
			// join()
			// wait for this thread to die
			thread.join();
			flag = thread.isAlive();
			if (flag == true) {
				System.out.println(thread.getName() + ": is alive ");

			} else {
				System.out.println(thread.getName() + ": is dead ");

			}

		}

	}

}
