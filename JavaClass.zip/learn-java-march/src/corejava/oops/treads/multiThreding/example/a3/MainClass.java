package corejava.oops.treads.multiThreding.example.a3;


public class MainClass {

	public static void main(String[] args) {
		for (int i = 1; i < 6; i++) {
			MultiThreading t1 = new MultiThreading(i);
			t1.start();
		}
	}

}
