package corejava.oops.treads.multiThreding.example.a2;

public class MainClass {

	public static void main(String[] args) {
		for (int i = 1; i < 6; i++) {
			MultiThreading t1 = new MultiThreading();
			t1.start();
		}
	}

}
