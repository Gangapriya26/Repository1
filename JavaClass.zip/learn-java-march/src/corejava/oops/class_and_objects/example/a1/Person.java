package corejava.oops.class_and_objects.example.a1;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
