package corejava.oops.interfaceConcept.functional.example.a1;

public interface Animal {
	public void sound();
	
}
