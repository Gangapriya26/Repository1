package corejava.oops.interfaceConcept.functional.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Animal cat;
		cat = new Animal() {

			@Override
			public void sound() {
				System.out.println("meow meow");
			}};
			cat.sound();
			
			Animal dog;
			dog = new Animal() {

				@Override
				public void sound() {
					System.out.println("bow bow ");
					
				}};
				dog.sound();
				Animal cow;
				cow = new Animal() {

					@Override
					public void sound() {
						System.out.println("Ambaa Ambaaa");
						
					}
					
				};
				cow.sound();
	}

}
