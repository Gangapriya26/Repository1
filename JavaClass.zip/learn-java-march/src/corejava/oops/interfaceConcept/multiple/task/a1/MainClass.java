package corejava.oops.interfaceConcept.multiple.task.a1;


//create interface "PayTM"
		// create abstract method "paymentViaPayTM" in interface "PayTM"

		// create interface "GooglePay"
		// create abstract method "paymentViaGooglePay" in interface "GooglePay"

		// create class HDFCBank which implements interface "PayTM" & "GooglePay"
		// create class ICICIBank which implements interface "PayTM" & "GooglePay"

		// in Main class create object of interface "PayTM" & "GooglePay"
		// and execute
public class MainClass {

	public static void main(String[] args) {
		GooglePay g;
		g = new ICICIBank();
		g.paymentViaGooglePay();
		g=new HDFCBank();
		g.paymentViaGooglePay();
		
		PayTM p;
		p=new ICICIBank();
		p.paymentViaPayTM();
		p=new HDFCBank();
		p.paymentViaPayTM();
		
	}

}
