package corejava.oops.interfaceConcept.multiple.task.a1;

public interface PayTM {
	public void paymentViaPayTM();
	

}
