package corejava.oops.interfaceConcept.multiple.task.a1;
 
public class HDFCBank implements PayTM,GooglePay {

	@Override
	public void paymentViaPayTM() {
		System.out.println("Amount debited from HDFC bank, payment done through payTM");
	}

	@Override
	public void paymentViaGooglePay() {
		System.out.println("Amount debited from HDFC bank, payment done through G-pay");		
	}

}
