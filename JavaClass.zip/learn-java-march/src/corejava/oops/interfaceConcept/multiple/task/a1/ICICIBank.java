package corejava.oops.interfaceConcept.multiple.task.a1;

public class ICICIBank implements GooglePay,PayTM{

	@Override
	public void paymentViaPayTM() {
		System.out.println("Amount debited from ICICI bank, payment done through PayTM");		
	}
		
	

	@Override
	public void paymentViaGooglePay() {
		System.out.println("Amount debited from ICICI bank, payment done through G-pay");		
	}
		
	}


