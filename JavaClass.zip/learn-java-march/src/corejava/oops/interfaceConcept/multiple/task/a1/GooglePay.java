package corejava.oops.interfaceConcept.multiple.task.a1;

public interface GooglePay {
	public void paymentViaGooglePay();

}
