package corejava.oops.interfaceConcept.multiple.example.a1;

public class MainClass {
	public static void main(String[] args) {
//		Swiggy s;
//		s=new Swiggy();
//		s.deliverFromNandanaPalace();
//		s.deliverFromEmpire();
//		
//		Zomato z;
//		z=new Zomato();
//		z.deliverFromEmpire();
//		z.deliverFromNandanaPalace();
		
		Empire e;
		e=new Swiggy();
		e.deliverFromEmpire();
		
		e=new Zomato();
		e.deliverFromEmpire();
		
		NandanaPalace n;
		n=new Swiggy();
		n.deliverFromNandanaPalace();
		
		n=new Zomato();
		n.deliverFromNandanaPalace();
		
	}

}
