package corejava.oops.interfaceConcept.multiple.example.a1;

public interface Empire {
	public void deliverFromEmpire();
}
