package corejava.oops.interfaceConcept.multiple.example.a1;

public class Zomato implements Empire,NandanaPalace {

	@Override
	public void deliverFromNandanaPalace() {
		System.out.println("deliverd from Nandana through Zomato");
	}

	@Override
	public void deliverFromEmpire() {
		System.out.println("deliverd from Empire through Zomato");		
	}

}
