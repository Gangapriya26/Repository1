package corejava.oops.interfaceConcept.multiple.example.a1;

public class Swiggy implements NandanaPalace,Empire {

	@Override
	public void deliverFromNandanaPalace() {
		System.out.println("deliverd from Nandana through swiggy");
	}

	@Override
	public void deliverFromEmpire() {
		System.out.println("deliverd from Empire through swiggy");
	}

}
