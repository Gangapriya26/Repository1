package corejava.oops.interfaceConcept.staticConstants.example.a1;

public class MainClass {
	public static void main(String[] args) {
//		ConstantsInterface c;
		System.out.println("pi value="+ConstantsInterface.PI);
//		ConstantsInterface.PI=7;
		System.out.println("project location :"+ConstantsInterface.PROJECT_DIR);
		
	}

}
