package corejava.oops.interfaceConcept.staticConstants.example.a1;

public interface ConstantsInterface {

	public static double PI = 3.14159;// constants should be write in capital

	
	//for location
	public static String PROJECT_DIR=System.getProperty("user.dir");
}
