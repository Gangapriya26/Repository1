package corejava.oops.interfaceConcept.single.task.a1;

public interface Course {
	public void Subject();

}
