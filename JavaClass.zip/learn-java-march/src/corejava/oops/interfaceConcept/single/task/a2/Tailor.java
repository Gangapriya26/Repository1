package corejava.oops.interfaceConcept.single.task.a2;

public interface Tailor {
	public void Stich();

}
