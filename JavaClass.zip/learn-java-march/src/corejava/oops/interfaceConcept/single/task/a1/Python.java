package corejava.oops.interfaceConcept.single.task.a1;

public class Python implements Course{

	@Override
	public void Subject() {
		System.out.println("Python is easy to learn in coding language");
	}

}
