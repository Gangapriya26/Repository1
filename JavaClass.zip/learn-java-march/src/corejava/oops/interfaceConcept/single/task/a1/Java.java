package corejava.oops.interfaceConcept.single.task.a1;

public class Java implements Course{

	@Override
	public void Subject() {
		System.out.println("I am currently learning Java");
	}

}
