package corejava.oops.interfaceConcept.single.task.a2;

public class Saree implements Tailor{

	@Override
	public void Stich() {
		System.out.println(" I gave Saree colour Black");
	}

}
