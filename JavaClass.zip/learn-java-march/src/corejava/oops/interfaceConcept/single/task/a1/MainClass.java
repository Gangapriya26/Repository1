package corejava.oops.interfaceConcept.single.task.a1;

//Create a interface called Course
	// create a abstract method name subject() inside Course
	// Provide implementation of subject method in two classes
	// namely Java and Python
	// Execute in the Main class
public class MainClass {

	public static void main(String[] args) {
		Course c;
		c=new Java();
		c.Subject();
		c = new Python();
		c.Subject();
	}

}
