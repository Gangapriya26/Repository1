package corejava.oops.interfaceConcept.single.task.a2;

public class Kurtha implements Tailor{

	@Override
	public void Stich() {
		System.out.println("I gave Kurtha color is blue");
	}

}
