package corejava.oops.interfaceConcept.single.task.a2;
//Create interface Tailor
		// In Tailor interface define abstract method stitch()
		// Create 2 classes 1. Shirt and 2. Pant
		// which provides implementation of stitch()
		// method from Tailor interface
		// Show implementation by using object of 
		// Tailor interface in Main Method
public class MainClass {

	public static void main(String[] args) {
		Tailor t;
		t=new Kurtha();
		t.Stich();
		t=new Saree();
		t.Stich();

	}

}
