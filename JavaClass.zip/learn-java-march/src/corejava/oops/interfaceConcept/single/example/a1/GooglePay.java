package corejava.oops.interfaceConcept.single.example.a1;

public class GooglePay implements Swiggy{

	@Override
	public void payment() {
		System.out.println("payment donwe through G-Pay");
		
	}
	

}
