package corejava.oops.interfaceConcept.single.example.a1;

public class PhonePay implements Swiggy {

	@Override
	public void payment() {
		System.out.println("Payment done through phonepay");
	}

}
