package corejava.oops.interfaceConcept.single.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Swiggy s;
		s =new GooglePay();
		s.payment();
		s=new PhonePay();
		s.payment();
		
	}

}
