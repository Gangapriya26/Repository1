package corejava.oops.interfaceConcept.single.example.a1;

public interface Swiggy {
	public void payment();

}
