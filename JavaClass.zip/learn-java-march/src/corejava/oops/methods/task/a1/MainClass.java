package corejava.oops.methods.task.a1;

public class MainClass {
	// Create a POJO class "Cat"
	// In Cat class create 2 instance variables namely
	// 1. "name" of type String
	// 2. "age" of type int
	// In Main Class create a method called printCat()
	// should print cat object **

	

	public static void main(String[] args) {
		printCat();

	}
	public static void printCat() {
		Cat c = new Cat();
		c.name = "Cherry";
		c.age = 3;
		System.out.println("Cat name: " + c.name);
		System.out.println("Cat age: " + c.age);
		

	}

}
