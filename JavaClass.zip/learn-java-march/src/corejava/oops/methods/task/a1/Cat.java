package corejava.oops.methods.task.a1;

public class Cat {
	public String name;
	public int age;
	

}
