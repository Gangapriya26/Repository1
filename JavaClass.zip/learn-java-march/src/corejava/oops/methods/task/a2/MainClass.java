package corejava.oops.methods.task.a2;



//Create a class Box which defines 3 instance variables
	// 1. width of type double
	// 2. height of type double
	// 3. depth of type double
	// Define a method printVolume() to calculate volume of Box
	// Write a program and demonstrate with the help of 2 Box objects
	// and print them in console.

public class MainClass {

	public static void main(String[] args) {
		Box Box1 = new Box();
		Box1.width = 12;
		Box1.height = 13;
		Box1.depth = 23;
		Box1.printVolume();

		Box Box2 = new Box();
		Box2.width = 122;
		Box2.height = 133;
		Box2.depth = 233;
		Box2.printVolume();

	}

}
