package corejava.oops.methods.task.a2;

public class Box {
	public double width;
	public double height;
	public double depth;

	public void printVolume() {
		double volume = width * height * depth;
		System.out.println("Volume is:" + volume);
	}

}
