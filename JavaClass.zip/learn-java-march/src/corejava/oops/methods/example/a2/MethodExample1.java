package corejava.oops.methods.example.a2;

public class MethodExample1 {

	public static void main(String[] args) {
		iAmCompleteMethod();
	}

	// {} is called as code block
	// in method is called as method implement
	// {} method body
	// Concrete Method //Implemented method

	public static void iAmCompleteMethod() {
		System.out.println("I am Method");
	}

//incomplete method //abstract method
//public static void iAmIncompltetMethod();

}
