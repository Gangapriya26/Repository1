package corejava.oops.methods.example.a2;

public class MethodExample2 {
	public static void printName() {
		String name = "Krishu";
		System.out.println("Name is : " + name);
	}

	public static void printAge() {
		int age = 4;
		System.out.println("Age is: " + age);

	}

	public static void main(String[] args) {
		printName();
		printAge();

	}

}
