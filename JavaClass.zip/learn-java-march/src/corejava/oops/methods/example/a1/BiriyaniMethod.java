package corejava.oops.methods.example.a1;
//we can write the method body at the end of class or beginning of class
public class BiriyaniMethod {
//	public static void  makeBiriyani() {
//	
	//body of the method
//	
//	System.out.println("Step1: Go to market");
//	System.out.println("Step2: Buy vegetables");
//	System.out.println("Step3: Cut the vegetables");
//	System.out.println("Step4: Wash the rice");
//	System.out.println("Step5: Add the incredients");
//	System.out.println("Step6: Cook for the 30min ");
//	System.out.println("Step7: Biriyani is ready to eat");
//}

	public static void main(String[] args) {

//		System.out.println("Step1: Go to market");
//		System.out.println("Step2: Buy vegetables");
//		System.out.println("Step3: Cut the vegetables");
//		System.out.println("Step4: Wash the rice");
//		System.out.println("Step5: Add the ingredients");
//		System.out.println("Step6: Cook for the 30min ");
//		System.out.println("Step7: Biriyani is ready to eat");
		
		makeBiriyani();
		System.out.println();
		makeBiriyani();//printing two times a biriyani code  //reuse the code
		
		
		
	}
	
	public static void  makeBiriyani() {
		
		//body of the method
		
		System.out.println("Step1: Go to market");
		System.out.println("Step2: Buy vegetables");
		System.out.println("Step3: Cut the vegetables");
		System.out.println("Step4: Wash the rice");
		System.out.println("Step5: Add the incredients");
		System.out.println("Step6: Cook for the 30min ");
		System.out.println("Step7: Biriyani is ready to eat");
	}

}
