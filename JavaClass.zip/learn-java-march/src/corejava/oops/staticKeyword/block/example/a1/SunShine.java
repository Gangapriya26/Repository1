package corejava.oops.staticKeyword.block.example.a1;

public class SunShine {
	
	//static block
	static{
		System.out.println("I am static block");
		}
	
	//non static or instance keyword
	{
		System.out.println("iI am non static block");
	}
	
	

}
