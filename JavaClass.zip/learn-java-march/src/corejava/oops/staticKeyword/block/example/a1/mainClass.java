package corejava.oops.staticKeyword.block.example.a1;

public class mainClass {

	public static void main(String[] args) throws ClassNotFoundException {
		//both static and non static block will print 
		//SunShine  sun =new SunShine();
		
		//only static block will be executed
		//Qualified class name==package name=class name
	
		Class.forName("corejava.oops.staticKeyword.block.example.a1.SunShine");
		
		
		//class loader
		//Qualified class name==package name=class name
		
	}

}
