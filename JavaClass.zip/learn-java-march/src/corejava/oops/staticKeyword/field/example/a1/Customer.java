package corejava.oops.staticKeyword.field.example.a1;

public class Customer {
	public static String city;

}
