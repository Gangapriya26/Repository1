package corejava.oops.staticKeyword.field.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Customer.city = "Manglore";
		System.out.println("Customer city:"+Customer.city);
		
		Customer.city="Gulbarga";
		System.out.println("Customer city:"+Customer.city);
		
		
		Customer c1=new Customer();
		//we should not use object/reference variable to reference to refer static fields
//		c1.city="Banglore";
	}

}
