package corejava.oops.staticKeyword.method.example.a1;

class MainClass {

	public static void main(String[] args) {
		int result = MathOperation.add(2, 4);
		System.out.println("result of add" + result);
	}

}
