package corejava.oops.staticKeyword.method.example.a1;

public class MathOperation {
	
	public static  int add(int a,int b) {
		int sum = a+b;
		return sum;
		
	}
}
