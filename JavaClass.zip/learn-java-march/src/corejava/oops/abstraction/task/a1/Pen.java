package corejava.oops.abstraction.task.a1;

public abstract class Pen {
	public abstract void refillcolor();
	
}
