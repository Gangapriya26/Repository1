package corejava.oops.abstraction.task.a1;

public class Black extends Pen{

	@Override
	public void refillcolor() {
		System.out.println("Refilcolor is Black");
	}
	

}
