package corejava.oops.abstraction.task.a1;


	// create class called Pen{}
			// create abstract method called refillColor() in it.
			// create class Black{} which provides implementation of refillColor
			// from Pen class
			// create class Blue{} which provides implementation of refillColor
			// from Pen class
			// show the implementation with the help of 1 reference variables
			// of type Pen class
public class MainClass {
	public static void main(String[] args) {
		Pen p;
//		p=new Pen();
		
		p=new Black();
		p.refillcolor();
		p=new Blue();
		p.refillcolor();
	}

}
