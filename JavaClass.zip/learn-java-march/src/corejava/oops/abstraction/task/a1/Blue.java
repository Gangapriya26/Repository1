package corejava.oops.abstraction.task.a1;

public class Blue extends Pen{

	@Override
	public void refillcolor() {
		System.out.println("refillcolor is Blue");
	}

}
