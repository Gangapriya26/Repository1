package corejava.oops.abstraction.task.a2;
//Create abstract class Bank
	// In Bank class create abstract method transaction()
	// which takes amount of type double as parameter
	// In Bank class create concrete method getName()
	// which takes name of type string as parameter
	// Provide implementation od transaction method 
	// in 2 different classes namely 1. Deposit 2. Withdraw
	// Show implementation using objects in Main Class

public class MainClass {

	public static void main(String[] args) {

	}

}
