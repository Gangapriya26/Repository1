package corejava.oops.abstraction.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Zomato z;
//		z=new Zomato();
		z = new GooglePay();
		z.food();
		z.payment();
		z = new PhonePay();
		z.food();
		z.payment();
	}

}

