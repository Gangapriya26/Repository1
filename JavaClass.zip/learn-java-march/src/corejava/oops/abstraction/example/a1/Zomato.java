package corejava.oops.abstraction.example.a1;

public abstract class Zomato {


	// incomplete method
	// abstract method
	// public void payment();
	public abstract void payment();
	
	//normal method //concrete method
	public void food() {
		System.out.println("food delivered by zomato");
	}

}

