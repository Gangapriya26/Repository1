package corejava.oops.abstraction.example.a1;

public class PhonePay extends Zomato {

	@Override
	public void payment() {
		System.out.println("Payment collected using Ppay");
	}

}
