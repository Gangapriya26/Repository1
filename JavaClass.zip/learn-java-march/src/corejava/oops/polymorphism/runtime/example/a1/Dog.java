package corejava.oops.polymorphism.runtime.example.a1;

public class Dog extends Animal{
	@Override
	public void sound() {
		System.out.println("Dog sounds like Bow Bow");
	}

}
