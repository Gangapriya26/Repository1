package corejava.oops.polymorphism.runtime.example.a1;

public class Cat extends Animal{
	@Override
	public void sound() {
		System.out.println("Cat makes sound like Meow Meow");
	}
}
