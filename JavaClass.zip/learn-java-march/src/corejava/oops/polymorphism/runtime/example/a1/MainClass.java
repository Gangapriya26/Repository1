package corejava.oops.polymorphism.runtime.example.a1;

public class MainClass {

	public static void main(String[] args) {
		//creating objects for class
		Animal a1=new Animal();//animal reference  and animal object both are of type animal
		Animal d1=new Dog();//Animal reference and dog object
		Animal  c1=new Cat();//Animal reference and cat  object
		
		//calling the sound method()
		a1.sound();
		d1.sound();
		c1.sound();
		
		
// Run-Time Polymorphism:
// In the main method, myDog and myCat are references of type Animal
// points to objects of Dog and Cat, respectively.
// When sound() is called on these references,
// the JVM determines at runtime which version of // the sound() method to execute (either Dog's
//Dogs or Cat's), not the Animal's.
// This is an example of run-time polarise where the method to be invoked is
// determined at runtime based on the actual project that the reference variatis
// points to.
		
	}

}
