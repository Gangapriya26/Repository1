package corejava.oops.polymorphism.runtime.example.a1;

public class Animal {
	public void sound() {
		System.out.println("Animal makes a sound");
	}

}
