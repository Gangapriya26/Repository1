package corejava.oops.polymorphism.example.a1;

public class Clerk extends Employee {
	

}
