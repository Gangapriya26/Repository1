package corejava.oops.polymorphism.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Employee e1=new Employee();
		e1.name="Sunil";
		
		Clerk c1=new Clerk();
		c1.name="Santhosh";
		
		Manager m1=new Manager();
		m1.name="Sathvik";
		
		printEmployee(e1);//same method allowing for different objects also
		printEmployee(c1);
		printEmployee(m1);
		
		printClerk(c1);
//		printClerk(e1);
//		printClerk(m1);
		
		
		printManager(m1);
//		printManager(c1);
//		printManager(e1);
	
	}
	public static void printEmployee(Employee e) {
		System.out.println("Employee name: "+e.name);
		
	}
	public static void printClerk(Clerk c) {
		System.out.println("Clerk name:"+ c.name);
		
	}
	public static void printManager(Manager m) {
		System.out.println("Manager name:"+ m.name);
		
	}

}
