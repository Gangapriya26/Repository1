package corejava.oops.userInput.example.a3;

import java.util.Scanner;

public class ScannerBugExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number:");
		int number = sc.nextInt();
		
		//ADD one empty nextLine() so as to make the next nextLine() work properly
		sc.nextLine();
		System.out.println("Enter a name:");
		String name = sc.nextLine();
		sc.close();
		System.out.println("Entered number is: " + number);
		System.out.println("Entered name is : " + name);

	}

}
