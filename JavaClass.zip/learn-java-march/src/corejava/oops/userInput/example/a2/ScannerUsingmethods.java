package corejava.oops.userInput.example.a2;

import java.util.Scanner;
//create method add() for addition which takes 2 numbers as input
	// and returns the value
	// create method multiply() for multiplication which 2 numbers as input
	// and returns the value
	// You are allowed to create any extra method if required
public class ScannerUsingmethods {
	public static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		
		int result1=add();
		System.out.println("Addition :"+result1);
		int result2=multiply();
		System.out.println("Mulltiply:"+result2);
	}

	public static int takeInput() {
//		Scanner sc =new Scanner(System.in);
		System.out.print("Enter a number  : ");
		int number=sc.nextInt();
//		sc.close();
//		System.out.print("The Entered number  is : " + number);
		return number;
		

	}

	public static int  add() {
		int num1=takeInput();
		int num2=takeInput();
		int total=num1+num2;
		return total;
		
		
	}
	public static int  multiply() {
		int num1=takeInput();
		int num2=takeInput();
		int total=num1*num2;
		return total;
		
		
	}

}
