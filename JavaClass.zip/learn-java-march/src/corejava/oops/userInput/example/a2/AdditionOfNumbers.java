package corejava.oops.userInput.example.a2;

import java.util.Scanner;

public class AdditionOfNumbers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("entered 1st namber : ");
		int num1=sc.nextInt();
		System.out.println("1st number is : "+num1);
		System.out.print("entered 2nd namber : ");
		int num2=sc.nextInt();
		System.out.println("2nd number is : "+num2);
		int result=num1+num2;
		
		//output format 2+2=4 
		System.out.println("Addition o two number is : " + num1+" + "  + num2+" =" + result);
		sc.close();
		
}
	

}
