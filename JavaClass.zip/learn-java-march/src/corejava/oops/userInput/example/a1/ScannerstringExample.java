package corejava.oops.userInput.example.a1;

import java.util.Scanner;

public class ScannerstringExample {

	public static void main(String[] args) {
		Scanner string =new Scanner(System.in);
		System.out.print("Enter a name : ");
		String name=string.nextLine();
		System.out.println("Entered name is : "+name);
		string.close();
		
		
//		System.out;  //out is a static variable in System
		
	}

}
