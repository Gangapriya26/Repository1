package corejava.oops.userInput.example.a1;

import java.util.Scanner;

public class ScannerIntExample {

	public static void main(String[] args) {
		Scanner integer = new Scanner(System.in);
		System.out.print("enter a number : ");
		int number = integer.nextInt();
		System.out.println("the numbered entered is "+number);
		integer.close();

	}

}
