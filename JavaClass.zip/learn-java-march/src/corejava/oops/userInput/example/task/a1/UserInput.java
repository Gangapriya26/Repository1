package corejava.oops.userInput.example.task.a1;

import java.util.Scanner;

//take name as user input
	// take age as user input
	// display the name and age in the console
	// show the output of name as "Name: John"
	// show the output of age as "Age: 20"

public class UserInput {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a name of person:");
		
		String name=sc.nextLine();
		System.out.println("Entered name is : "+name);
		System.out.print("Enter a age of person : ");
		int age=sc.nextInt();
		
		System.out.println("age of person : "+ age);
		sc.close();
		
		
		
	}

}
