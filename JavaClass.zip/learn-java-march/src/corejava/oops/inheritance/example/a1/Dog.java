package corejava.oops.inheritance.example.a1;

public class Dog extends Animal{

}
