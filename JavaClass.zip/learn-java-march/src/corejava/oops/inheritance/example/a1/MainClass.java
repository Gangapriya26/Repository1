package corejava.oops.inheritance.example.a1;



public class MainClass {

	public static void main(String[] args) {
		Animal myAnimal1=new Animal();
		myAnimal1.sound();
		
		Cat myCat =new Cat();
		myCat.sound();
		
		Dog myDog=new Dog();
		myDog.sound();
	}

}
