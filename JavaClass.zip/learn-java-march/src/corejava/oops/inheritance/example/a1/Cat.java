package corejava.oops.inheritance.example.a1;

public class Cat extends Animal {

}
