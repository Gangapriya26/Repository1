package corejava.oops.inheritance.example.a2;

public class Clerk extends Employee {
	public int bribe;

}
