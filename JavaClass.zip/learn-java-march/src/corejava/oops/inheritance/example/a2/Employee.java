package corejava.oops.inheritance.example.a2;

public class Employee {

	public String name;
	public String city;

}
