package corejava.oops.inheritance.example.a2;

public class MainClass {

	public static void main(String[] args) {
		Manager m1 = new Manager();
		m1.name = "James";
		m1.city = "Mumbai";
		m1.teamMembers = 15;
		System.out.println("Manager name:" + m1.name);
		System.out.println("Manager city:" + m1.city);
		System.out.println("Manager teamMembers:" + m1.teamMembers);

		Clerk c1 = new Clerk();
		c1.name = "SHivamma";
		c1.city = "Mumbai";
		c1.bribe = 10;
		System.out.println("Clerk name :" + c1.name);
		System.out.println("Clerk city :" + c1.city);
		System.out.println("Clerk bribe :" + c1.bribe);
	}

}
