package corejava.oops.inheritance.example.a2;

public class Manager extends Employee{
	public int teamMembers;
	
	
}
