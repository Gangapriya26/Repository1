package corejava.oops.inheritance.task.a1;

public class MainClass {

	//create class called superclass{}
	//create method called print() in super class
	//create class called subclass{} and make it child of superclass
	//create class called mainclass{}
	//create object of superclass and subclass and execute it 
	public static void main(String[] args) {
		SuperClass s1=new SuperClass();
		s1.print();
		
		SubClass s2=new SubClass();
		s2.print();
	}

}
