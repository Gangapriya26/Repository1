package corejava.oops.inheritance.task.a1;

public class SuperClass {
	public  void print() {
		System.out.println("I am Super class");
		
	}

}
