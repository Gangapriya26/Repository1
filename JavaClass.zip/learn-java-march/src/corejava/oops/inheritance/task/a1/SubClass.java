package corejava.oops.inheritance.task.a1;

public class SubClass extends SuperClass{

}
