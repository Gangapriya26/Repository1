package corejava.oops.inheritance.overriding.example.a1;

public class Dog extends Animal{
	@Override
	public void sound() {
		System.out.println("Bow Bow");
		
	}

}
