package corejava.oops.inheritance.overriding.example.a1;

public class Animal {
	public void sound() {
		System.out.println("Animal make sound");

	}
	public void Eat() {
		System.out.println("Animal is eating");
	}
	
}
