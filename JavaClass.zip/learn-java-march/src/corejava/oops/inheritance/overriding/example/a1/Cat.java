package corejava.oops.inheritance.overriding.example.a1;

public class Cat extends Animal{
	
	@Override
	public void sound() {
		System.out.println("Meow Meow");
		
	}

}
