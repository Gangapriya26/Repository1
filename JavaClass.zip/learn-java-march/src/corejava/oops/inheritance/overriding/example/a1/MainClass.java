package corejava.oops.inheritance.overriding.example.a1;

public class MainClass {
	public static void main(String[] args) {
		Animal myAnimal1 = new Animal();
		myAnimal1.sound();
		myAnimal1.Eat();

		Cat myCat = new Cat();
		myCat.sound();
		myCat.Eat();

		Dog myDog = new Dog();
		myDog.sound();
		myDog.Eat();
	}

}
