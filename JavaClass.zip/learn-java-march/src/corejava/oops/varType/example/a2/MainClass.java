package corejava.oops.varType.example.a2;

public class MainClass {

	public static void main(String[] args) {
		var v1=new Cat("Smoookey",2);
		System.out.println("cat name"+v1.getName());
		System.out.println("cat age"+v1.getAge());
	}

}
