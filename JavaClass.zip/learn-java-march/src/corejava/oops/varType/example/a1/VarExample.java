package corejava.oops.varType.example.a1;import java.lang.invoke.VarHandle;

public class VarExample {

	public static void main(String[] args) {
		//byte
		var byteNumber = 127;
		System.out.println(byteNumber);
		
		//short
		var shortNumber=1234;
		System.out.println(shortNumber);
		
		//int 
		var intNumber=1234567;
		System.out.println(intNumber);
		
		//long 
		var longNumber=123_456_789;
		System.out.println(longNumber);
		//float
		var floatNumber=12.243;
		System.out.println(floatNumber);
		
		//double
		var doubleNumnber=123456.234;
		System.out.println(doubleNumnber);
		
		//char 
		var character='1';
		System.out.println(character);
		
		//cannot use var all variable without initializer
//		var name;
		
		//boolean
		var flag=true;
		System.out.println(flag);
		
		
		
	}

}
