package corejava.oops.modifiers.access.protected_keyword.example.a1;

public class ProtectedMainClass {

	public static void main(String[] args) {
		Vehicle v2 =new Vehicle() ;
		v2.type="auto";
		v2.wheels=3;
		v2.printVehicle();
	}

}
