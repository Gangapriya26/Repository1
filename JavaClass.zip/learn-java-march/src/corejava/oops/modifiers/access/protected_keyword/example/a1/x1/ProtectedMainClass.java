package corejava.oops.modifiers.access.protected_keyword.example.a1.x1;

import corejava.oops.modifiers.access.protected_keyword.example.a1.Vehicle;

public class ProtectedMainClass {

	public static void main(String[] args) {
		Vehicle v3=new Vehicle();
		
		////access not allowed for protected variables or fields from different package
//		v3.type="Lorry";
//		v3.wheels=8;
//		v3.printVehicle();
//		
	}

}
