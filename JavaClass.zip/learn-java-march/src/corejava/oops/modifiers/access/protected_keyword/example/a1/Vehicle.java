package corejava.oops.modifiers.access.protected_keyword.example.a1;



public class Vehicle {
	protected String type;
	protected int wheels;
	protected void printVehicle() {
		System.out.println("vehicle type:"+type);
		System.out.println("vehicle wheels:"+wheels);
	}
	public static void main(String[] args) {
		Vehicle v1=new Vehicle();
		v1.type="Car";
		v1.wheels=4;
		v1.printVehicle();
		
	}

}
