package corejava.oops.modifiers.access.protected_keyword.example.a1.x1;

import corejava.oops.modifiers.access.protected_keyword.example.a1.Vehicle;
import corejava.oops.modifiers.access.protected_keyword.example.a1.VehicleChildClass;

public class VehicleChild extends Vehicle{
	public void printVehicleChild() {
		System.out.println("vehicle child type:"+type);
		System.out.println("vehicle child wheels:"+wheels);
		
		
	}
	public static void main(String[] args) {
		VehicleChild vc2=new VehicleChild();
		vc2.type="bus";
		vc2.wheels=6;
		vc2.printVehicleChild();
		
	}

}
