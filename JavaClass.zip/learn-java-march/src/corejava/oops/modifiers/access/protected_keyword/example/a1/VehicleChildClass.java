package corejava.oops.modifiers.access.protected_keyword.example.a1;



public class VehicleChildClass extends Vehicle{
	public void printVehicleChild() {
		System.out.println("vehicle child type:"+ type);
		System.out.println("vehicle child wheels:"+wheels);
	}
	
	public static void main(String[] args) {
		VehicleChildClass vc1=new VehicleChildClass();
		vc1.type="bike";
		vc1.wheels=2;
		vc1.printVehicleChild();
		
	}
}
