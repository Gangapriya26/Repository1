package corejava.oops.modifiers.access.defaultConcept.example.a1.x1;

import corejava.oops.modifiers.access.defaultConcept.example.a1.Hospital;

public class DefaultMainClass {

	public static void main(String[] args) {
		Hospital h3=new Hospital();
		//access not allowed for default fields from different package
//		h3.name="st. johns";
//		h3.beds=120;
//		h3.printHospital();
	}

}
