package corejava.oops.modifiers.access.defaultConcept.example.a1.x1;

import corejava.oops.modifiers.access.defaultConcept.example.a1.Hospital;

public class HospitalChild  extends Hospital{
	
	public void printHospital() {
		//access not allowed for default fields from different package
//		System.out.println("Hospital  child name:"+name);
//		System.out.println("Hospital child beds:"+beds);
	}

	public static void main(String[] args) {
		Hospital hc2=new Hospital();
//		hc2.name="Ashraya";
//		hc2.beds=15;
//		hc2.printHospital();

	}

}
