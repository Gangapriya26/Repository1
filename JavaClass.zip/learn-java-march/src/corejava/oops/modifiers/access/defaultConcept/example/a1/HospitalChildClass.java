package corejava.oops.modifiers.access.defaultConcept.example.a1;

public class HospitalChildClass extends Hospital {
	public void printHospital() {
		System.out.println("Hospital name:"+name);
		System.out.println("Hospital beds:"+beds);
	}
	public static void main(String[] args) {
		Hospital hc1=new Hospital();
		hc1.name="Nimhance";
		hc1.beds=150;
		hc1.printHospital();
		
	}

}
