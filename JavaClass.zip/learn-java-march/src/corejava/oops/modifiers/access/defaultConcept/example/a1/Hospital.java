package corejava.oops.modifiers.access.defaultConcept.example.a1;

public class Hospital {
	String name;
	int beds;
	
	void printHospital() {
		System.out.println("Hospital name:"+name);
		System.out.println("Hospital beds:"+beds);
	}
	public static void main(String[] args) {
		Hospital h1=new Hospital();
		h1.name="jayadeva";
		h1.beds=500;
		h1.printHospital();
	}
}
