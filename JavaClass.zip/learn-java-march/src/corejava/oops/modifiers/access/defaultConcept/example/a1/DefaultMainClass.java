package corejava.oops.modifiers.access.defaultConcept.example.a1;

public class DefaultMainClass {

	public static void main(String[] args) {
		Hospital h2=new Hospital();
		h2.name="kims";
		h2.beds=200;
		h2.printHospital();
	}

}
