package corejava.oops.modifiers.access.private_keyword.example.a1;

public class PrivateMainClass {

	public static void main(String[] args) {
		Movie m2=new Movie();
		
		//access not allowed for private variables or fields
//		m2.name="KGF";
//		m2.genre="Action";
//		m2.printMovie();
	}

}
