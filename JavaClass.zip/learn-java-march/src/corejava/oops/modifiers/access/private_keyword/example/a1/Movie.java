package corejava.oops.modifiers.access.private_keyword.example.a1;

public class Movie {
	private String name;
	private String genre;

	private void printMovie() {
		System.out.println("movie name is : " + name);
		System.out.println("movie genre is : " + genre);

	}
	public static void main(String[] args) {
		Movie m1=new Movie();
		m1.name="Varastara";
		m1.genre="Comedy";
		m1.printMovie();
	}
}
