package corejava.oops.modifiers.access.private_keyword.example.a1;

public class MovieChild {
	public void printMovie() {
		// access not allowed for private variables or fields
		// even for child or sub class
//		System.out.println("movie name is:"+name);
//		System.out.println("movie genre is:"+genre);
	}

	public static void main(String[] args) {
		Movie m3 = new Movie();

		// access not allowed for private variables or fields
		// even for child or sub class
//		m3.name="f2";
//		m3.genre="Comedy";
		// access not allowed for private methods
//		m3.printMovie();
	}

}
