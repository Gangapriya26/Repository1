package corejava.oops.modifiers.access.public_keyword.example.a1;

public class Farmer {
	public String village;
	public int cows;

	public void printFarmer() {
		System.out.println("farmer village " + village);
		System.out.println("farmer cows " + cows);
	}

}
