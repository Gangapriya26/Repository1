package corejava.oops.modifiers.access.public_keyword.example.a1.x1;

import corejava.oops.modifiers.access.public_keyword.example.a1.Farmer;

public class FarmerChild extends Farmer{
	public void printFarmerChild() {
		System.out.println("farmer child village "+village);
		System.out.println("farmer child cows "+cows);
	}
	public static void main(String[] args) {
		FarmerChild fc2=new FarmerChild();
		fc2.village="palya";
		fc2.cows=33;
		fc2.printFarmerChild();
	}

}
