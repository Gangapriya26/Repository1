package corejava.oops.modifiers.access.public_keyword.example.a1.x1;

import corejava.oops.modifiers.access.public_keyword.example.a1.Farmer;

public class PublicMainClass {

	public static void main(String[] args) {
		Farmer farmer2 = new Farmer();
		farmer2.village = "kolya";
		farmer2.cows = 11;
		farmer2.printFarmer();
	}

}
