package corejava.oops.modifiers.access.public_keyword.example.a1;

public class FarmerChild extends Farmer{
	public void printFarmerChild() {
		System.out.println("farmer child village "+village);
		System.out.println("farmer child cows "+cows);
	}
	public static void main(String[] args) {
		FarmerChild fc1=new FarmerChild();
		fc1.village="kanakpur";
		fc1.cows=23;
		fc1.printFarmerChild();
	}
}
