package corejava.oops.modifiers.access.public_keyword.example.a1;

public class PublicMainClass {

	public static void main(String[] args) {
		Farmer farmer1 = new Farmer();
		farmer1.village = "kundapura";
		farmer1.cows = 10;
		farmer1.printFarmer();
//		System.out.println(farmer1.village);
//		System.out.println(farmer1.cows);

		FarmerChild fc1 = new FarmerChild();
		fc1.village = "kanakpur";
		fc1.cows = 23;
		fc1.printFarmerChild();

	}

}
