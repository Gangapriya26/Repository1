package corejava.oops.innerClass.methodLocalInnerClass.example.a1;

public class Outer {
	public void y() {
		System.out.println("y from outer class");
		class Inner {
			void x() {
				System.out.println("x from inner class");
			}

		}// end of inner
		Inner i=new Inner();
		i.x();
	}// end of method
}// end of outer
