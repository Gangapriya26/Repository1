package corejava.oops.innerClass.staticInnerClass.example.a1;

public class Outer {
	public static class Inner {
		public void x() {
			System.out.println("x from inner class");

		}//end of x

	}//end inner

}//end outer
