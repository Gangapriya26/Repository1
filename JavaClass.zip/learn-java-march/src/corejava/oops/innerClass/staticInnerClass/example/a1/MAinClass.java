package corejava.oops.innerClass.staticInnerClass.example.a1;

public class MAinClass {

	public static void main(String[] args) {
		Outer o = new Outer();
		Outer.Inner i = new Outer.Inner();
		i.x();
		
	}

}
