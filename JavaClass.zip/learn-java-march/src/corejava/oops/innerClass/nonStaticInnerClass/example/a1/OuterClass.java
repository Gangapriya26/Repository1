package corejava.oops.innerClass.nonStaticInnerClass.example.a1;

//example of non static inner class
public class OuterClass {
	public int number = 6 ;
	
	public void heyThere() {
		System.out.println("Hey there!");
	}
	public  class InnerClass{
		public int innerNumber=10;
		
		public void whatsUp() {
			System.out.println("WhatsUp from the inner class");
			
		}
		
	}
}
