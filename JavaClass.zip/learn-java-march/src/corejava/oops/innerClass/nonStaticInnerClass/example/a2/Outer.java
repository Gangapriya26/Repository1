package corejava.oops.innerClass.nonStaticInnerClass.example.a2;
//non static inner class
public class Outer {

	public class Inner {
		public void x() {
			System.out.println("x from inner class");
			
		}//end of x
	}//end of inner
}//end of outer