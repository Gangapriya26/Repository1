package corejava.oops.innerClass.nonStaticInnerClass.example.a2;

public class MainClass {

	public static void main(String[] args) {
//		Inner i = new Inner();
		Outer o =new Outer();
		
		Outer.Inner i=o.new Inner();
		i.x();
		
	}

}
