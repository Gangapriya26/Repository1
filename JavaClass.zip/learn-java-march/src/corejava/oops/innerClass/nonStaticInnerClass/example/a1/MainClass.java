package corejava.oops.innerClass.nonStaticInnerClass.example.a1;


public class MainClass {

	public static void main(String[] args) {
		OuterClass outer = new OuterClass();
		System.out.println(outer.number);
		outer.heyThere();

		// InnerClass inner =new InnerClass();
		OuterClass.InnerClass inner = outer.new InnerClass();
		System.out.println(inner.innerNumber);
		inner.whatsUp();

	}

}
