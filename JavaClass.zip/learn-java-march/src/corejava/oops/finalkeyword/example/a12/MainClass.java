package corejava.oops.finalkeyword.example.a12;

public class MainClass {
	public static final double PI=3.14159;

	
	public static void main(String[] args) {
		double PI = 3.14159;
		System.out.println(PI);

		// final variable can be initialize only once
//		PI =9;
//		System.out.println(PI);
		printPI();
	}
	public static void  printPI() {
		System.out.println("Value of PI:"+PI);
	}

}
