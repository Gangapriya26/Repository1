package corejava.oops.finalkeyword.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Dog d1=new Dog();
		d1.Eat();
		d1.Sound();
		
//		Animal d2=new Animal();
//		d2.Sound();
//		
		d1=new Dog();
		final Dog d2;
		d2 =new Dog();
		
		//final variable can be initializedd only once
//		d2=new Dog();
	}

}
