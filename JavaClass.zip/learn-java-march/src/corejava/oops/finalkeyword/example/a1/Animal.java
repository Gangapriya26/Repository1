package corejava.oops.finalkeyword.example.a1;

//public final class Animal {
public class Animal {
	public String name;
	public String colour;

	public final void Eat() {
		System.out.println("Animals were eat through thier mouth");
	}

	public  void Sound() {
		System.out.println("Animal making sound ");
	}

}
