package corejava.oops.finalkeyword.example.a1;

public class Dog extends Animal {
	@Override
	public void Sound() {
		System.out.println("Dog making sound like Bow Bow");
	}
	
	//child class is not allowed to override final method from parent class
//	@Override
//	public void Eat() {
//		System.out.println("champ champ");
//	}
//	

}
