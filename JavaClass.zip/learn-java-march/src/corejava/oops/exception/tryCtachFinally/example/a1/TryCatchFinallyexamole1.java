package corejava.oops.exception.tryCtachFinally.example.a1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatchFinallyexamole1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int number = 0;
		try {
			System.out.println("Enter a number");
			number = sc.nextInt();
			System.out.println("number entered is " + number);
		} catch (InputMismatchException e) {
			System.out.println("you have not  enter a number ");
//			System.out.println(e);
			e.printStackTrace();

		} finally {
			System.out.println("Scanner closed");
			sc.close();

		}
		sc.close();

	}

}
//when we get a error then it jumps to catch block
