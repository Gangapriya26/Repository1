package corejava.oops.exception.example.a1;

//Exception 
//Arithmetic Exception 
public class ExceptionExample1 {

	public static void main(String[] args) {

		int a = 2;
		int b = 0;
		int result;
		
		//code without handling exception 
		//Division
		result=a/b;
		System.out.println("Hello World");
		System.out.println(result);
		
		//Addition 
		result = a+b;
		System.out.println(result);
		
		
	}

}
