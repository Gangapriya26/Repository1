package corejava.oops.exception.example.a1;

//NullPointerException 

public class ExceptionExample2 {

	public static void main(String[] args) {
		String name=null;
		
		
		if(name.equals("abc")){
			System.out.println("name is equals to abc");
		}else {
			System.out.println("name is not equals to abc");
		}
		System.out.println("Programm finished");
		
	}

}
