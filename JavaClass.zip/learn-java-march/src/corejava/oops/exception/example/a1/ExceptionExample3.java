package corejava.oops.exception.example.a1;

//ArrayIndexOutOfBoundsException  

public class ExceptionExample3 {

	public static void main(String[] args) {
		String[] cityArray= {"Banglore","Chickmanglore","Manglore"};
		System.out.println(cityArray[3]);
		
		System.out.println("Programm finished ");
	}

}
