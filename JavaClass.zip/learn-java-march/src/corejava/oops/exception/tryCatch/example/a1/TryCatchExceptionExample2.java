package corejava.oops.exception.tryCatch.example.a1;

public class TryCatchExceptionExample2 {

	public static void main(String[] args) {
		String name = null;

		// code with exception handling
		try {
			if (name.equals("abc")) {
				System.out.println("name is equals to abc");
			} else {
				System.out.println("name is not equals to abc");
			}
//		} catch (NullPointerException e) {
		} catch (Exception e) {
			
			e.printStackTrace();
			System.out.println("Something went wrong ");

		}

		System.out.println("Programm finished");
	}

}
