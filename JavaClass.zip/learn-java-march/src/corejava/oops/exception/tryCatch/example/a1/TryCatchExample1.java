package corejava.oops.exception.tryCatch.example.a1;

public class TryCatchExample1 {

	public static void main(String[] args) {
		int a = 2;
		int b = 0;
		int result = 0;

		// code with handling exception
		
		try {
			// Division
			result = a / b;
		}
		catch(ArithmeticException e) {
//			System.out.println(e);
//			System.err.println(e);
			e.printStackTrace();//it is inbuilt method to shoes lot of information about exception 
		}
		System.out.println("Hello World");
		System.out.println("Division = " + result);

		// Addition
		result = a + b;
		System.out.println("Addition = " + result);

	}

}
