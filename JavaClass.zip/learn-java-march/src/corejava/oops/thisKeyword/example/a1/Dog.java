package corejava.oops.thisKeyword.example.a1;

public class Dog {
	private String name;
	private int age;

	public void setName(String name) {
		this.name = name;

	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;

	}

	public int getAge() {
		return age;
	}

	public void printDog() {
		System.out.println("Dog:" + this);
		System.out.println("Dog age is : " + this.age);

	}

}
