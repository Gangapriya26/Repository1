package corejava.oops.thisKeyword.example.a1;

public class Mainclass {

	public static void main(String[] args) {
		Dog d1 = new Dog();
		System.out.println(d1);// hash code
		d1.setName("Poco");
		d1.setAge(2);
		d1.printDog();// hashcode

		Dog d2 = new Dog();
		d2.setName("Chummy");
		d2.setAge(8);
		d2.printDog();

	}

}
