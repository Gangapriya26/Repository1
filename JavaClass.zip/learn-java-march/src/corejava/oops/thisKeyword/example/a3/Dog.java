package corejava.oops.thisKeyword.example.a3;

public class Dog {
	private String name;
	private int age;
	
	public Dog(String name,int age) {
	//	System.out.println("hi"); //this should be 1st calling even sysout
		this(name);
		this.age=age;
	}
	public Dog(String name) {
		this.name=name;
	}
	public Dog() {
	this("no name",1);
	}
	public Dog(int age) {
		this.age=age;
	}
	//usage of this keyword is no allowed in static context
	//public static void printStuff(String){
	//this.name=name;

	public void setName(String name) {
		this.name = name;

	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;

	}

	public int getAge() {
		return age;
	}

	public void printDog() {
		System.out.println("Dog:" + this);
		

	}

}
