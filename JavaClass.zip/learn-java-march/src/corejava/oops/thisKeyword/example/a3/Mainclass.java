package corejava.oops.thisKeyword.example.a3;

public class Mainclass {

	public static void main(String[] args) {
		Dog d1 = new Dog("lio",2);
		System.out.println(d1);// hash code
		d1.printDog();// hashcode
//		d1.setName("Poco");
//		d1.setAge(2);
		System.out.println("dog name:"+d1.getName());
		System.out.println("dog age:"+d1.getAge());
		
		Dog d2=new Dog("LIO");
		System.out.println("dog name:"+d2.getName());
		System.out.println("dog age:"+d2.getAge());
		
		
		Dog d3=new Dog();
		System.out.println("Dog name:"+d3.getName());
		System.out.println("Dog age:"+d3.getAge());
	}

}
