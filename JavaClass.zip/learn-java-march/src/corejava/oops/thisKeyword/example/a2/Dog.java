package corejava.oops.thisKeyword.example.a2;

public class Dog {
	private String name;
	private int age;
	
	public Dog(String name,int age) {
		this.name=name;
		this.age=age;
	}
	
	//usage of this keyword is no allowed in static context
	//public static void printStuff(String){
	//this.name=name;

	public void setName(String name) {
		this.name = name;

	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;

	}

	public int getAge() {
		return age;
	}

	public void printDog() {
		System.out.println("Dog:" + this);
		

	}

}
