package corejava.oops.encapsulation.task.a1;

public class MainClass {
	//create  a customer class
	//create 2 variable
	//implement encapsulation in customer class
	//in main method create 2 object of customer class
	//to demonstrate encapsulation
	
	

	public static void main(String[] args) {
		Customer c1=new Customer();
		c1.setName("Akshaya");
		c1.setCity("Banglore");
		System.out.println("Customer name is: "+c1.getName());
		System.out.println("Customer city is: "+c1.getCity());
		
		
		Customer c2=new Customer();
		c2.setName("Akshitha");
		c2.setCity("Chikmanglore");
		System.out.println("Customer name is: "+c2.getName());
		System.out.println("Customer city is: "+c2.getCity());
		
		
	}

}
