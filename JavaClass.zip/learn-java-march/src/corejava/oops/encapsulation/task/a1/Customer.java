package corejava.oops.encapsulation.task.a1;

public class Customer {
	private String name;
	private String city;
	
	public void setName(String n) {
		name=n;
		
	}
	public String getName() {
		return name;
	}
	public void setCity(String c) {
		city=c;
	}
	public String getCity() {
		return city;
	}
	

}
