package corejava.oops.encapsulation.example.a1;

public class Dog {
	private String name;
	private int age;

	public void setName(String n) {
		name = n;

	}

	public String getName() {
		return name;
	}

	public void setAge(int i) {
		age = i;
	}

	public int getAge() {
		return age;
	}

}
