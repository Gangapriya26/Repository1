package corejava.oops.encapsulation.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Dog d1 = new Dog();
//		d1.name="Jully";
//		d1.age=6;
		d1.setName("Jully");
		d1.setAge(6);
		System.out.println("dog name is :" + d1.getName());
		System.out.println("dog age is : " + d1.getAge());
		
		Dog d2=new Dog();
		d2.setName("Jockey");
		d2.setAge(10);
		System.out.println("Dog name is : " + d2.getName());
		System.out.println("Dog age is : " + d2.getAge());

	}

}
