package corejava.oops.files.example.a1;

import java.io.File;

public class CreateFileExample1{

	public static void main(String[] args) {
		String filePath = "D:\\files\\dog.txt";
		File f ;
		try {
			f= new File(filePath);
			f.createNewFile();
		} 
		catch (Exception e) {
			System.out.println("something went wrong ");
			e.printStackTrace();

		}
		System.out.println("File Created at : " + filePath);
	}

}
