package corejava.oops.files.example.a1;

import java.io.File;
import java.io.IOException;

public class DeleteFileExample1 {
	
	public static void main(String[] args) {
			String filePath="D:\\files\\dog.txt";
			File f ;
			try {
				f = new File(filePath);
				
				//check whether file is present or not 
				if (f.exists()) {
					//delete the file 
					System.out.println("file delete at :"+filePath);
				}
				else {
					System.out.println("file not found at :"+filePath);
					
				}
				
			}
			catch(Exception e  ){
				e.printStackTrace();
				System.out.println("Something went wrong ");
				
			}
			
	}
}
