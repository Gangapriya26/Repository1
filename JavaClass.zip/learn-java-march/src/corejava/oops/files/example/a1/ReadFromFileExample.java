package corejava.oops.files.example.a1;

import java.io.FileReader;
import java.io.IOException;

//fileReader class
//read()
//it reads from file and returns character at a time 
// if it reaches end of file , it returns -1

public class ReadFromFileExample {

	public static void main(String[] args) throws IOException {
		String filePath = "C:\\files\\dog.txt";
		String text = "";
		FileReader fr = null;
		try {
			fr = new FileReader(filePath);
			int data;
			while ((data = fr.read()) != -1) {
				text = text + (char)data;
			}
			System.out.println(text);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Something went eromg");
		} finally {
			fr.close();

		}
	}

}
