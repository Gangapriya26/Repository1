package corejava.oops.files.example.a1;

import java.io.File;

public class DeleteFileExample2 {
	public static void main(String[] args) {
		String filePath="D:\\files\\dog.txt";
		File f ;
		try {
			f = new File(filePath);
			
			//check whether file is present or not 
			if (f.exists()) {
				//delete the file 
				if(f.delete()) {
					System.out.println("file delete at :"+filePath);
				}else {
					System.out.println("file not found at :"+filePath);
					
					
				}
				
				
			}
			else {
				System.out.println("file not found at :"+filePath);
				
				
			}
			
		}
		catch(Exception e  ){
			e.printStackTrace();
			System.out.println("Something went wrong ");
			
		}
		
}

}
