package corejava.oops.files.example.a1;

import java.io.FileOutputStream;
import java.io.IOException;

//fileOutputstream
//write(byteArea)
public class WriteToFileUsingFileOutput {

	public static void main(String[] args) throws IOException {
		String filePath="D:\\files\\dog.txt";
		String text="""
				Johny johny ?yes pappa;
				eating suger ?no paapa;
				telling lie ?no paapa;
				open your mouth ? ha ha ha !!!!
				""";
		byte[] textArray = text.getBytes();
		FileOutputStream  fos = null;
		try {
			fos = new FileOutputStream(filePath);
			fos.write(textArray);
			System.out.println("wrote file at "+filePath);
		}
		catch(IOException e) {
			
		}
		finally {
		fos.close();
			
		}
	}

}
