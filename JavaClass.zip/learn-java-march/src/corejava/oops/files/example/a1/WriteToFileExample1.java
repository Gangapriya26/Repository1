package corejava.oops.files.example.a1;

import java.io.FileWriter;
import java.io.IOException;

//file Writer class
//we can use file writer class to create a object of file writer class
//and we write () method 
public class WriteToFileExample1 {

	public static void main(String[] args) throws IOException {
		String filePath="D:\\files\\dog.txt";
		String text="""
				Johny johny ?yes pappa;
				eating suger ?no paapa;
				telling lie ?no paapa;
				open your mouth ? ha ha ha !!!!
				""";
		System.out.println(text);
		FileWriter fw = null;
		try {
			fw = new FileWriter(filePath);
			fw.write(text);
			System.out.println("Wrote file at : "+filePath);
		}

		catch(Exception e) {
			e.printStackTrace();
			System.out.println("something went wrong ");
			
		}
		finally {
			fw.close();
		}
	}

}
