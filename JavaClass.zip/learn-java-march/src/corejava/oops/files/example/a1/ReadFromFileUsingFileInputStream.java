package corejava.oops.files.example.a1;

import java.io.FileInputStream;
import java.io.IOException;

//fileInputStream Class
//read()
//it returns from file and returns byte at a time 
//if it reaches end of file , it returns -1 

public class ReadFromFileUsingFileInputStream {

	public static void main(String[] args) throws IOException {
		String filePath = "C:\\files\\dog.txt";
		String text = " ";
		FileInputStream	fis = null;
		try {
			fis = new FileInputStream(filePath);
			int data ;
			while ((data = fis.read())!=-1) {
				text =text +(char ) data;
			
				
			}
			System.out.println(text);
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Something went wrong ");
		}
		finally {
			fis.close();
		}
	}
	

}
