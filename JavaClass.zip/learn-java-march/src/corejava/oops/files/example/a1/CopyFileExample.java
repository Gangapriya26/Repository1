package corejava.oops.files.example.a1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

//FileInputStream class
//FileOutputStream class 
public class CopyFileExample {

	public static void main(String[] args) throws IOException{
		String source="C:\\Users\\ganga\\OneDrive\\Pictures\\priya.jpeg";
		String target="C:\\Users\\ganga\\OneDrive\\Pictures\\duplicate_priya.jpeg";
		
		FileInputStream fis= null;
		FileOutputStream fos= null;
		try {
			fis = new FileInputStream(source);
			fos = new FileOutputStream(target);
			int data;
			while ((data=fis.read())!=-1) {
				fos.write(data);;
			}
			System.out.println("read from file "+source);
			System.out.println("wrote to  file "+target);
			
			
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Something went wrong ");
			
		}
		finally {
			fis.close();
			fos.close();
			
		}
		
	}

}
