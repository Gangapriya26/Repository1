package corejava.oops.files.example.a1;

import java.io.File;

public class CreateFileExampple3 {
	public static void main(String[] args) {
		String filePath = "D:\\files\\dog.txt";
		File f;
		try {
			f = new File(filePath);
			if (f.exists()) {
				System.out.println("File Created at : " + filePath);

			} else {
				System.out.println("File already Exist at : " + filePath);

			}

		} catch (Exception e) {
			System.out.println("something went wrong ");
			e.printStackTrace();

		}

	}

}
