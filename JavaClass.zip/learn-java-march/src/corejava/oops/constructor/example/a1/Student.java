package corejava.oops.constructor.example.a1;

public class Student {

	public String name;
	public String city;
	
	//no argument constructor--- no parameter inside u doing something
	public Student() {
		System.out.println("I am constructor");

}
//
//	//Default constructor
//	public Student() {	
//}
	
	
	//
	public Student(String n,String c) {
		name = n;
		city = c;
		
	}
	public Student(String n) {
		name = n;
		city = "Mysore";//default value
	}

}
