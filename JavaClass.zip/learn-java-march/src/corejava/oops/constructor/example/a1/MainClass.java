package corejava.oops.constructor.example.a1;

public class MainClass {

	public static void main(String[] args) {
		Student s1 = new Student();// we are calling the constructor here
		System.out.println(s1.name);//null
		System.out.println(s1.city);//null
		
//		s1.name = "Jack Willow";
//		s1.city = "Banglore";
//		System.out.println(s1.name);
//		System.out.println(s1.city);
		
		Student s2= new Student("jacker ", "new york");
		System.out.println(s2.name);//jacker
		System.out.println(s2.city);//new york
		
		
		Student s3=new Student("Chirayuu");
		System.out.println(s3.name);//Chirayuu
		System.out.println(s3.city);//null
		

	}

}
