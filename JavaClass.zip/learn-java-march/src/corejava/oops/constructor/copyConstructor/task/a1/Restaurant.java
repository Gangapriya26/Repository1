package corejava.oops.constructor.copyConstructor.task.a1;

public class Restaurant {
	public String dish;
	public int price;

	public Restaurant(String d, int p) {
		dish = d;
		price = p;

	}
	// copy constructor

	public Restaurant(Restaurant r) {
		dish = r.dish;
		price = r.price;

	}
	
	
	

}
