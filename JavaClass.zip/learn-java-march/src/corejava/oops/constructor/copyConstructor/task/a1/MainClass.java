package corejava.oops.constructor.copyConstructor.task.a1;

public class MainClass {
	// Create POJO class Restaurant
		// In Restaurant class create 2 instance variables namely:
		// 1. String dish;
		// 2. int price;
		// Create 2 constructors in Restaurant class
		// 1. Constructor will all parameters
		// 2. Copy Constructor
		// Execute in Main Class using both constructors.

	public static void main(String[] args) {
		
		Restaurant r1=new Restaurant("Chicken Biriyani",200);
		System.out.println(r1.dish);
		System.out.println(r1.price);
		System.out.println(r1);
		
		Restaurant r2=new Restaurant (r1);
		System.out.println(r2.dish);
		System.out.println(r2.price);
		System.out.println(r2);
		
		r2.dish="Palav";
		r2.price=150;
		System.out.println(r2.dish);
		System.out.println(r2.price);
		System.out.println(r2);
	}

}
