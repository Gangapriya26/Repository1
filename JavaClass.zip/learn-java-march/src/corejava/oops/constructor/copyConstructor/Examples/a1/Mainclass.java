package corejava.oops.constructor.copyConstructor.Examples.a1;

public class Mainclass {

	public static void main(String[] args) {
		Song s1 = new Song("Nagarjun", "Mayaavi");
		System.out.println(s1.artist);
		System.out.println(s1.movie);
		System.out.println(s1);// hash code

		Song s2 = new Song("Arjith Sing", "KAbhi Kushi Kabh");
		System.out.println("Song Artist:" + s2.artist);
		System.out.println("movie name:" + s2.movie);
		System.out.println(s2);
		
		Song s3=s2; //Shallow copy
		System.out.println(s3);
		
		Song s4=new Song (s1);
		System.out.println("Song name:"+s4.artist);
		System.out.println("movie name:"+s4.movie);
		System.out.println(s4);//hash code
		
		s4.artist="SPB";
		s4.movie="Sangathi neenu";
		System.out.println(s4.artist);
		System.out.println(s4.movie);
		System.out.println(s4);
		
		
	}
}