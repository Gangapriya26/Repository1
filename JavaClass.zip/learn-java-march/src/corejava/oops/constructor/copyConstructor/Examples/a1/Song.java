package corejava.oops.constructor.copyConstructor.Examples.a1;

public class Song {
	public String artist;
	public String movie;

	public Song(String a, String m) {
		artist = a;
		movie = m;
		
	}
	
	//copy constructor
	public Song (Song s) {
		artist =s.artist;
		movie=s.movie;
	}
}
