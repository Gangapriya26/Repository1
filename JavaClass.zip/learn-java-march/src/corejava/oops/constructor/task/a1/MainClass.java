package corejava.oops.constructor.task.a1;

public class MainClass {

	// create POJO class constructor
	// instance variable name of type string
	// instance variable age of type int
	// create a No argument constructor
	// create a constructor with 1 parameter of each instance variable
	// create a constructor with 2 parameter
	// in main class create objects for execution
	public static void main(String[] args) {
		
		
		Task t1 = new Task("Akshatha", 20);
		System.out.println(t1.name);
		System.out.println(t1.age);

		
		
		Task t2 = new Task("Deepika");
		System.out.println(t2.name);

		
		Task t3 = new Task();
		System.out.println(t3.name);
		System.out.println(t3.age);

	}

}
