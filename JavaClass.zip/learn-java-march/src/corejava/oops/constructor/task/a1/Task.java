package corejava.oops.constructor.task.a1;

public class Task {
	public String name;
	public int age;

	public Task() {
		System.out.println("NO argument Constuctor");

	}

	public Task(String n, int a) {
		name = n;
		age = a;

	}
	public Task(String n) {
		name = n;
		

	}

}
