package corejava.oops.constructor.task.a2;

public class Employee {
	public String name;
	public String city;
	
	//no argument constructor
	
	public Employee () {
		name = "Kattappa";
		city="Tamil Nadu";
	}

	public Employee(String n, String c) {
		name = n;
		city = c;
	}
	
	//with one parameter
	public Employee(String n) {
		name = n;
	
	}

}
