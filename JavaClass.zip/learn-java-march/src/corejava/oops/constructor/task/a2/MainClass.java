package corejava.oops.constructor.task.a2;

public class MainClass {

	// create class employee
	// 2 instance variable
	// string name
	// string city
	// create all the possible constructor in main class
	// execute and show the output
	public static void main(String[] args) {

		Employee e1 = new Employee();
		System.out.println("Employee e1:"+e1.name);
		System.out.println(e1.city);
		
		Employee e2 = new Employee("Teju","bnglr");
		System.out.println(e2.name);
		System.out.println(e2.city);
		
		Employee e3 = new Employee("Gopal");
		System.out.println(e3.name);
		System.out.println(e3.city);
		
	

	}

}
